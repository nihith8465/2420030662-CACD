"""
Hybrid Threat Classifier: Machine Learning Model + Rule-Based Explainability.
"""
import os
import joblib
import numpy as np
from typing import Dict, Any, Tuple
from .preprocessor import extract_feature_vector
from .rule_engine import evaluate_security_rules

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MODEL_PATH = os.path.join(BASE_DIR, "models", "model.joblib")
SCALER_PATH = os.path.join(BASE_DIR, "models", "scaler.joblib")
ENCODER_PATH = os.path.join(BASE_DIR, "models", "label_encoder.joblib")

_model = None
_scaler = None
_label_encoder = None

def load_ml_assets():
    global _model, _scaler, _label_encoder
    if _model is None and os.path.exists(MODEL_PATH):
        _model = joblib.load(MODEL_PATH)
        _scaler = joblib.load(SCALER_PATH)
        _label_encoder = joblib.load(ENCODER_PATH)

SEVERITY_MAPPING = {
    'BENIGN': 'INFO',
    'PortScan': 'MEDIUM',
    'Web Attack': 'HIGH',
    'Brute Force': 'HIGH',
    'DoS/DDoS': 'CRITICAL',
    'Botnet': 'CRITICAL'
}

def classify_security_event(record: Dict[str, Any]) -> Dict[str, Any]:
    """
    Classifies a security log record using hybrid ML + Rule evaluation,
    and enforces perimeter firewall drops if source IP is quarantined.
    Returns structured threat classification details.
    """
    source_ip = str(record.get('source_ip', '')).strip()
    if source_ip:
        from .database import is_ip_blocked
        if is_ip_blocked(source_ip):
            return {
                'predicted_label': 'DROPPED (FIREWALL)',
                'confidence': 1.0,
                'severity': 'CRITICAL',
                'detection_source': 'FIREWALL',
                'rule_triggered': 'FIREWALL_DROP: Source IP is quarantined in active blacklist',
                'description': f'Connection rejected & dropped at firewall perimeter. Source {source_ip} is in active quarantine.'
            }

    load_ml_assets()

    rule_attack, rule_severity, rule_reason = evaluate_security_rules(record)

    # ML Inference
    features = extract_feature_vector(record)
    X = np.array([features])
    
    if _model and _scaler and _label_encoder:
        X_scaled = _scaler.transform(X)
        probs = _model.predict_proba(X_scaled)[0]
        pred_idx = np.argmax(probs)
        ml_label = _label_encoder.inverse_transform([pred_idx])[0]
        ml_conf = float(probs[pred_idx])
    else:
        # Fallback if model not yet loaded
        ml_label = rule_attack or 'BENIGN'
        ml_conf = 0.90 if rule_attack else 0.50

    # Hybrid Decision Matrix
    # If rule explicitly triggers an attack and ML is benign, rule takes precedence for explainable safety
    if rule_attack and ml_label == 'BENIGN':
        final_label = rule_attack
        detection_source = 'RULE'
        severity = rule_severity or SEVERITY_MAPPING.get(final_label, 'HIGH')
        confidence = 0.95
        explanation = rule_reason
    elif rule_attack and ml_label == rule_attack:
        final_label = ml_label
        detection_source = 'HYBRID'
        severity = rule_severity or SEVERITY_MAPPING.get(final_label, 'HIGH')
        confidence = max(ml_conf, 0.98)
        explanation = f"Corroborated by ML ({ml_conf*100:.1f}%) and {rule_reason}"
    else:
        final_label = ml_label
        detection_source = 'ML'
        severity = SEVERITY_MAPPING.get(final_label, 'LOW' if final_label == 'BENIGN' else 'MEDIUM')
        confidence = ml_conf
        explanation = f"Classified by AI Model with {ml_conf*100:.1f}% confidence" if final_label != 'BENIGN' else "Normal network traffic behavior"

    return {
        'predicted_label': final_label,
        'confidence': round(confidence, 4),
        'severity': severity,
        'detection_source': detection_source,
        'rule_triggered': rule_reason or "None",
        'description': explanation
    }
