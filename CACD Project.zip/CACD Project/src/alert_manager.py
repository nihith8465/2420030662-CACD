"""
Security Alert Manager.
Handles alert generation, severity tagging, and storage.
"""
from typing import Dict, Any, Optional
from .database import insert_log_record, insert_alert
from .classifier import classify_security_event

def process_and_record_log(raw_record: Dict[str, Any]) -> Dict[str, Any]:
    """
    Classifies a security event, stores it in the database with SHA-512 hash,
    and generates an alert if the event is malicious.
    """
    classification = classify_security_event(raw_record)

    # Merge classification into the record
    log_entry = dict(raw_record)
    log_entry['predicted_label'] = classification['predicted_label']
    log_entry['confidence'] = classification['confidence']
    log_entry['detection_source'] = classification['detection_source']

    # Insert into security_logs table (which computes and stores SHA-512 hash)
    log_id = insert_log_record(log_entry)
    log_entry['id'] = log_id

    # If classified as an attack or suspicious event, generate alert
    alert_info = None
    if classification['predicted_label'] != 'BENIGN':
        alert_payload = {
            'log_id': log_id,
            'timestamp': log_entry.get('timestamp', ''),
            'source_ip': log_entry.get('source_ip', '0.0.0.0'),
            'dest_ip': log_entry.get('dest_ip', '0.0.0.0'),
            'attack_type': classification['predicted_label'],
            'severity': classification['severity'],
            'confidence': classification['confidence'],
            'rule_triggered': classification['rule_triggered'],
            'description': classification['description'],
            'status': 'ACTIVE'
        }
        alert_id = insert_alert(alert_payload)
        alert_payload['id'] = alert_id
        alert_info = alert_payload

    return {
        'log_entry': log_entry,
        'classification': classification,
        'alert': alert_info
    }
