"""
Rule-Based Security Detection Engine.
Provides deterministic, explainable security alerts for known attack signatures and anomalies.
"""
from typing import Dict, Any, Optional, Tuple

def evaluate_security_rules(record: Dict[str, Any]) -> Tuple[Optional[str], Optional[str], Optional[str]]:
    """
    Evaluates rule-based heuristic patterns against the log record.
    Returns: (attack_type, severity, rule_description) or (None, None, None)
    """
    dest_port = int(record.get('dest_port', 0))
    failed_logins = int(record.get('failed_login_attempts', 0))
    flow_packets_s = float(record.get('flow_packets_per_sec', 0.0))
    flow_bytes_s = float(record.get('flow_bytes_per_sec', 0.0))
    syn_count = int(record.get('syn_flag_count', 0))
    ack_count = int(record.get('ack_flag_count', 0))
    rst_count = int(record.get('rst_flag_count', 0))
    fwd_pkts = int(record.get('total_fwd_packets', 0))
    bwd_pkts = int(record.get('total_bwd_packets', 0))

    # Rule 1: Brute-Force Authentication Attack
    if failed_logins >= 3:
        return (
            "Brute Force",
            "HIGH",
            f"Rule BRUTE_FORCE_01: Excessive failed authentication attempts ({failed_logins} failures detected)"
        )
    if dest_port in [21, 22] and failed_logins >= 1 and flow_packets_s > 50:
        return (
            "Brute Force",
            "HIGH",
            f"Rule BRUTE_FORCE_02: Rapid connection requests to SSH/FTP port {dest_port} with authentication failure"
        )

    # Rule 2: DoS / DDoS Flooding
    if syn_count > 50 and ack_count == 0:
        return (
            "DoS/DDoS",
            "CRITICAL",
            f"Rule DOS_SYN_FLOOD: SYN Flood detected ({syn_count} SYN packets without ACK responses)"
        )
    if flow_packets_s > 5000 or flow_bytes_s > 1000000:
        return (
            "DoS/DDoS",
            "CRITICAL",
            f"Rule DOS_RATE_SPIKE: Massive traffic rate detected ({flow_packets_s:.1f} pkts/s, {flow_bytes_s:.1f} B/s)"
        )

    # Rule 3: Port Scanning / Reconnaissance
    if syn_count > 5 and ack_count == 0 and bwd_pkts == 0:
        return (
            "PortScan",
            "MEDIUM",
            "Rule PORTSCAN_RECON: SYN scan pattern with zero backward acknowledgement packets"
        )
    if rst_count > 10 and fwd_pkts > 10:
        return (
            "PortScan",
            "MEDIUM",
            f"Rule PORTSCAN_RST: High RST packet ratio ({rst_count} RST flags) indicating probe responses"
        )

    # Rule 4: Web Application Attacks
    if dest_port in [80, 443, 8080, 8443] and (syn_count > 20 or rst_count > 15):
        return (
            "Web Attack",
            "HIGH",
            f"Rule WEB_ATTACK_01: Abnormal HTTP/HTTPS traffic pattern with high reset/handshake anomalies on port {dest_port}"
        )

    # Rule 5: Botnet Activity
    if dest_port in [6667, 1337, 31337, 4444] or (dest_port > 60000 and flow_packets_s > 100):
        return (
            "Botnet",
            "HIGH",
            f"Rule BOTNET_C2: Suspicious communication detected on known C2/backdoor port {dest_port}"
        )

    return (None, None, None)
