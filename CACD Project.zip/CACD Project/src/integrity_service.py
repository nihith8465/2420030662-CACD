"""
Cryptographic Integrity Service (SHA-512)
Provides tamper-detection and cryptographic audit trails for security records.
"""
import hashlib
import json
from typing import Dict, Any, Tuple, List

CANONICAL_FIELDS = [
    'timestamp',
    'source_ip',
    'dest_ip',
    'source_port',
    'dest_port',
    'protocol',
    'flow_duration',
    'total_fwd_packets',
    'total_bwd_packets',
    'total_fwd_bytes',
    'total_bwd_bytes',
    'flow_bytes_per_sec',
    'flow_packets_per_sec',
    'syn_flag_count',
    'ack_flag_count',
    'rst_flag_count',
    'failed_login_attempts',
    'predicted_label'
]

def build_canonical_payload(record: Dict[str, Any]) -> str:
    """
    Constructs a deterministic, sorted key-value string from core record fields.
    """
    items = []
    for field in sorted(CANONICAL_FIELDS):
        val = record.get(field, "")
        # Format floating numbers consistently if applicable
        if isinstance(val, float):
            val_str = f"{val:.4f}"
        else:
            val_str = str(val) if val is not None else ""
        items.append(f"{field}={val_str}")
    return "|".join(items)

def compute_sha512_hash(record: Dict[str, Any], previous_hash: str = "") -> str:
    """
    Generates a SHA-512 cryptographic hash for a given record,
    incorporating previous_hash to form an immutable hash chain (blockchain audit trail).
    """
    payload = build_canonical_payload(record)
    if previous_hash:
        payload = f"{payload}|prev_hash={previous_hash}"
    return hashlib.sha512(payload.encode('utf-8')).hexdigest()

def verify_record_hash(record: Dict[str, Any], stored_hash: str, previous_hash: str = "") -> Tuple[bool, str]:
    """
    Verifies if the record's current state and chain linkage match the stored SHA-512 hash.
    Returns (is_valid, current_computed_hash).
    """
    current_hash = compute_sha512_hash(record, previous_hash)
    return (current_hash.lower() == (stored_hash or "").lower(), current_hash)
