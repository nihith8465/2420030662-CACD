"""
SQLite Database Manager for Security Logs, Threat Alerts, and Integrity Audits.
"""
import sqlite3
import os
from typing import Dict, Any, List, Optional, Tuple
from .integrity_service import compute_sha512_hash, verify_record_hash

DB_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", "security_system.db")

def get_connection(db_path: str = DB_PATH) -> sqlite3.Connection:
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    return conn

def init_db(db_path: str = DB_PATH):
    os.makedirs(os.path.dirname(db_path), exist_ok=True)
    conn = get_connection(db_path)
    cursor = conn.cursor()

    # Security Logs Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS security_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp TEXT NOT NULL,
        source_ip TEXT NOT NULL,
        dest_ip TEXT NOT NULL,
        source_port INTEGER NOT NULL,
        dest_port INTEGER NOT NULL,
        protocol TEXT NOT NULL,
        flow_duration REAL DEFAULT 0.0,
        total_fwd_packets INTEGER DEFAULT 0,
        total_bwd_packets INTEGER DEFAULT 0,
        total_fwd_bytes INTEGER DEFAULT 0,
        total_bwd_bytes INTEGER DEFAULT 0,
        flow_bytes_per_sec REAL DEFAULT 0.0,
        flow_packets_per_sec REAL DEFAULT 0.0,
        syn_flag_count INTEGER DEFAULT 0,
        ack_flag_count INTEGER DEFAULT 0,
        rst_flag_count INTEGER DEFAULT 0,
        failed_login_attempts INTEGER DEFAULT 0,
        predicted_label TEXT NOT NULL,
        confidence REAL DEFAULT 1.0,
        detection_source TEXT DEFAULT 'HYBRID',
        previous_hash TEXT DEFAULT '',
        integrity_hash TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    """)

    # Firewall & Threat Quarantine Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS firewall_rules (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ip_address TEXT UNIQUE NOT NULL,
        reason TEXT,
        severity TEXT DEFAULT 'HIGH',
        status TEXT DEFAULT 'BLOCKED',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    """)

    # Alerts Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS alerts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        log_id INTEGER,
        timestamp TEXT NOT NULL,
        source_ip TEXT NOT NULL,
        dest_ip TEXT NOT NULL,
        attack_type TEXT NOT NULL,
        severity TEXT NOT NULL,
        confidence REAL DEFAULT 1.0,
        rule_triggered TEXT,
        description TEXT,
        status TEXT DEFAULT 'ACTIVE',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (log_id) REFERENCES security_logs (id)
    );
    """)

    # Audit History Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS integrity_audits (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp TEXT NOT NULL,
        total_checked INTEGER NOT NULL,
        passed INTEGER NOT NULL,
        tampered_count INTEGER NOT NULL,
        tampered_ids TEXT,
        status TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    """)

    # Column migrations
    try:
        cursor.execute("ALTER TABLE security_logs ADD COLUMN previous_hash TEXT DEFAULT ''")
    except sqlite3.OperationalError:
        pass
    try:
        cursor.execute("ALTER TABLE alerts ADD COLUMN resolution_notes TEXT DEFAULT ''")
    except sqlite3.OperationalError:
        pass
    try:
        cursor.execute("ALTER TABLE alerts ADD COLUMN resolved_by TEXT DEFAULT ''")
    except sqlite3.OperationalError:
        pass

    conn.commit()
    conn.close()

def normalize_record_for_storage(record: Dict[str, Any]) -> Dict[str, Any]:
    norm = dict(record)
    norm['timestamp'] = str(record.get('timestamp', ''))
    norm['source_ip'] = str(record.get('source_ip', '0.0.0.0'))
    norm['dest_ip'] = str(record.get('dest_ip', '0.0.0.0'))
    norm['source_port'] = int(record.get('source_port', 0) or 0)
    norm['dest_port'] = int(record.get('dest_port', 0) or 0)
    norm['protocol'] = str(record.get('protocol', 'TCP') or 'TCP')
    norm['flow_duration'] = float(record.get('flow_duration', 0.0) or 0.0)
    norm['total_fwd_packets'] = int(record.get('total_fwd_packets', 0) or 0)
    norm['total_bwd_packets'] = int(record.get('total_bwd_packets', 0) or 0)
    norm['total_fwd_bytes'] = int(record.get('total_fwd_bytes', 0) or 0)
    norm['total_bwd_bytes'] = int(record.get('total_bwd_bytes', 0) or 0)
    norm['flow_bytes_per_sec'] = float(record.get('flow_bytes_per_sec', 0.0) or 0.0)
    norm['flow_packets_per_sec'] = float(record.get('flow_packets_per_sec', 0.0) or 0.0)
    norm['syn_flag_count'] = int(record.get('syn_flag_count', 0) or 0)
    norm['ack_flag_count'] = int(record.get('ack_flag_count', 0) or 0)
    norm['rst_flag_count'] = int(record.get('rst_flag_count', 0) or 0)
    norm['failed_login_attempts'] = int(record.get('failed_login_attempts', 0) or 0)
    norm['predicted_label'] = str(record.get('predicted_label', 'BENIGN'))
    norm['confidence'] = float(record.get('confidence', 1.0) or 1.0)
    norm['detection_source'] = str(record.get('detection_source', 'HYBRID'))
    return norm

def insert_log_record(record: Dict[str, Any], db_path: str = DB_PATH) -> int:
    """
    Computes SHA-512 cryptographic hash with previous-hash blockchain-style chaining,
    and inserts record into security_logs.
    """
    clean_rec = normalize_record_for_storage(record)

    conn = get_connection(db_path)
    cursor = conn.cursor()

    # Get latest hash for chaining
    cursor.execute("SELECT integrity_hash FROM security_logs ORDER BY id DESC LIMIT 1")
    latest_row = cursor.fetchone()
    prev_hash = latest_row[0] if latest_row else ""
    clean_rec['previous_hash'] = prev_hash

    hash_val = compute_sha512_hash(clean_rec, prev_hash)
    clean_rec['integrity_hash'] = hash_val
    record['integrity_hash'] = hash_val
    record['previous_hash'] = prev_hash

    cursor.execute("""
        INSERT INTO security_logs (
            timestamp, source_ip, dest_ip, source_port, dest_port, protocol,
            flow_duration, total_fwd_packets, total_bwd_packets, total_fwd_bytes, total_bwd_bytes,
            flow_bytes_per_sec, flow_packets_per_sec, syn_flag_count, ack_flag_count, rst_flag_count,
            failed_login_attempts, predicted_label, confidence, detection_source, previous_hash, integrity_hash
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        clean_rec['timestamp'],
        clean_rec['source_ip'],
        clean_rec['dest_ip'],
        clean_rec['source_port'],
        clean_rec['dest_port'],
        clean_rec['protocol'],
        clean_rec['flow_duration'],
        clean_rec['total_fwd_packets'],
        clean_rec['total_bwd_packets'],
        clean_rec['total_fwd_bytes'],
        clean_rec['total_bwd_bytes'],
        clean_rec['flow_bytes_per_sec'],
        clean_rec['flow_packets_per_sec'],
        clean_rec['syn_flag_count'],
        clean_rec['ack_flag_count'],
        clean_rec['rst_flag_count'],
        clean_rec['failed_login_attempts'],
        clean_rec['predicted_label'],
        clean_rec['confidence'],
        clean_rec['detection_source'],
        prev_hash,
        hash_val
    ))
    log_id = cursor.lastrowid
    conn.commit()
    conn.close()
    return log_id

def block_ip(ip: str, reason: str = "Automated AI Threat Quarantine", severity: str = "HIGH", db_path: str = DB_PATH) -> bool:
    conn = get_connection(db_path)
    cursor = conn.cursor()
    cursor.execute("""
        INSERT OR REPLACE INTO firewall_rules (ip_address, reason, severity, status)
        VALUES (?, ?, ?, 'BLOCKED')
    """, (ip, reason, severity))
    conn.commit()
    conn.close()
    return True

def unblock_ip(ip: str, db_path: str = DB_PATH) -> bool:
    conn = get_connection(db_path)
    cursor = conn.cursor()
    cursor.execute("DELETE FROM firewall_rules WHERE ip_address = ?", (ip,))
    conn.commit()
    conn.close()
    return True

def get_blocked_ips(db_path: str = DB_PATH) -> List[Dict[str, Any]]:
    conn = get_connection(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM firewall_rules ORDER BY id DESC")
    rows = [dict(r) for r in cursor.fetchall()]
    conn.close()
    return rows

def is_ip_blocked(ip: str, db_path: str = DB_PATH) -> bool:
    conn = get_connection(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT id FROM firewall_rules WHERE ip_address = ? AND status = 'BLOCKED'", (ip,))
    row = cursor.fetchone()
    conn.close()
    return row is not None

def insert_alert(alert: Dict[str, Any], db_path: str = DB_PATH) -> int:
    conn = get_connection(db_path)
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO alerts (
            log_id, timestamp, source_ip, dest_ip, attack_type,
            severity, confidence, rule_triggered, description, status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        alert.get('log_id'),
        alert.get('timestamp', ''),
        alert.get('source_ip', ''),
        alert.get('dest_ip', ''),
        alert.get('attack_type', 'UNKNOWN'),
        alert.get('severity', 'MEDIUM'),
        float(alert.get('confidence', 1.0)),
        alert.get('rule_triggered', ''),
        alert.get('description', ''),
        alert.get('status', 'ACTIVE')
    ))
    alert_id = cursor.lastrowid
    conn.commit()
    conn.close()
    return alert_id

def get_logs(limit: int = 50, offset: int = 0, db_path: str = DB_PATH) -> List[Dict[str, Any]]:
    conn = get_connection(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM security_logs ORDER BY id DESC LIMIT ? OFFSET ?", (limit, offset))
    rows = [dict(r) for r in cursor.fetchall()]
    conn.close()
    return rows

def count_logs(db_path: str = DB_PATH) -> int:
    conn = get_connection(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM security_logs")
    count = cursor.fetchone()[0]
    conn.close()
    return count

def get_alerts(limit: int = 50, offset: int = 0, severity: Optional[str] = None, db_path: str = DB_PATH) -> List[Dict[str, Any]]:
    conn = get_connection(db_path)
    cursor = conn.cursor()
    if severity and severity.upper() != 'ALL':
        cursor.execute("SELECT * FROM alerts WHERE severity = ? ORDER BY id DESC LIMIT ? OFFSET ?", (severity.upper(), limit, offset))
    else:
        cursor.execute("SELECT * FROM alerts ORDER BY id DESC LIMIT ? OFFSET ?", (limit, offset))
    rows = [dict(r) for r in cursor.fetchall()]
    conn.close()
    return rows

def count_alerts(db_path: str = DB_PATH) -> int:
    conn = get_connection(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM alerts")
    count = cursor.fetchone()[0]
    conn.close()
    return count

def run_integrity_audit(db_path: str = DB_PATH) -> Dict[str, Any]:
    """
    Audits all stored logs against their cryptographic SHA-512 hashes and chain linkage.
    Flags any unauthorized records and logs the audit event.
    """
    import datetime
    import json

    conn = get_connection(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM security_logs ORDER BY id ASC")
    rows = cursor.fetchall()

    total_checked = len(rows)
    passed = 0
    tampered_ids = []
    tampered_details = []
    expected_prev_hash = ""

    for r in rows:
        record_dict = dict(r)
        stored_hash = record_dict.get('integrity_hash', '')
        actual_prev = record_dict.get('previous_hash', '')

        # Check hash validity
        is_valid, current_hash = verify_record_hash(record_dict, stored_hash, actual_prev)
        # Check chain linkage validity
        chain_broken = (actual_prev != expected_prev_hash) if expected_prev_hash != "" else False

        if is_valid and not chain_broken:
            passed += 1
        else:
            reason = "Hash mismatch" if not is_valid else "Chain linkage broken (re-ordered/deleted record)"
            tampered_ids.append(record_dict['id'])
            tampered_details.append({
                'id': record_dict['id'],
                'timestamp': record_dict['timestamp'],
                'source_ip': record_dict['source_ip'],
                'stored_hash': stored_hash,
                'computed_hash': current_hash,
                'reason': reason
            })
        expected_prev_hash = stored_hash

    tampered_count = len(tampered_ids)
    status = 'PASSED' if tampered_count == 0 else 'COMPROMISED'
    now_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    cursor.execute("""
        INSERT INTO integrity_audits (timestamp, total_checked, passed, tampered_count, tampered_ids, status)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (now_str, total_checked, passed, tampered_count, json.dumps(tampered_ids), status))
    conn.commit()
    conn.close()

    return {
        'timestamp': now_str,
        'total_checked': total_checked,
        'passed': passed,
        'tampered_count': tampered_count,
        'tampered_ids': tampered_ids,
        'tampered_details': tampered_details,
        'status': status
    }

def simulate_tampering(log_id: int, field_name: str = 'predicted_label', new_value: Any = None, db_path: str = DB_PATH) -> Tuple[bool, Any, Any]:
    """
    Directly modifies a user-specified field in a chosen log record without updating the SHA-512 hash,
    demonstrating unauthorized database tampering detection based on exact user inputs.
    """
    allowed_fields = [
        'predicted_label', 'source_ip', 'dest_ip', 'source_port', 'dest_port',
        'total_fwd_packets', 'total_fwd_bytes', 'flow_duration', 'syn_flag_count', 'failed_login_attempts'
    ]
    if field_name not in allowed_fields:
        field_name = 'predicted_label'

    conn = get_connection(db_path)
    cursor = conn.cursor()
    cursor.execute(f"SELECT {field_name} FROM security_logs WHERE id = ?", (log_id,))
    row = cursor.fetchone()
    if not row:
        conn.close()
        return (False, None, None)

    old_val = row[0]
    if new_value is None or str(new_value).strip() == "":
        if field_name == 'predicted_label':
            new_value = "BENIGN" if old_val != "BENIGN" else "DoS/DDoS"
        elif field_name in ['source_port', 'dest_port', 'total_fwd_packets', 'failed_login_attempts']:
            new_value = int(old_val or 0) + 100
        else:
            new_value = f"{old_val}_tampered"

    cursor.execute(f"UPDATE security_logs SET {field_name} = ? WHERE id = ?", (new_value, log_id))
    conn.commit()
    conn.close()
    return (True, old_val, new_value)

def resolve_alert_record(alert_id: int, analyst_name: str = "Analyst", resolution_notes: str = "", db_path: str = DB_PATH) -> bool:
    conn = get_connection(db_path)
    cursor = conn.cursor()
    cursor.execute("""
        UPDATE alerts 
        SET status = 'RESOLVED', resolved_by = ?, resolution_notes = ?
        WHERE id = ?
    """, (analyst_name, resolution_notes, alert_id))
    conn.commit()
    conn.close()
    return True
