"""
Data Preprocessing Module for Network and Security Logs.
Handles missing/infinite values, categorical encoding, and feature normalization.
"""
import numpy as np
import pandas as pd
from typing import Tuple, List, Dict, Any
from sklearn.preprocessing import StandardScaler

FEATURE_COLUMNS = [
    'dest_port',
    'flow_duration',
    'total_fwd_packets',
    'total_bwd_packets',
    'total_fwd_bytes',
    'total_bwd_bytes',
    'flow_bytes_per_sec',
    'flow_packets_per_sec',
    'syn_flag_count',
    'ack_flag_count',
    'rst_flag_count',
    'failed_login_attempts',
    'protocol_num'
]

# Mapping for common protocol strings to standard numbers
PROTOCOL_MAP = {
    'TCP': 6,
    'UDP': 17,
    'ICMP': 1,
    '6': 6,
    '17': 17,
    '1': 1
}

def clean_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    """
    Cleans raw DataFrame by standardizing column names, handling infinities, and dropping nulls.
    """
    # Normalize column names: lowercase, strip, replace spaces/slashes with underscore
    df = df.copy()
    df.columns = [c.strip().lower().replace(' ', '_').replace('/', '_') for c in df.columns]

    # Map possible alternative column names from CIC-IDS2017 to internal schema
    column_aliases = {
        'destination_port': 'dest_port',
        'dport': 'dest_port',
        'tot_fwd_pkts': 'total_fwd_packets',
        'total_fwd_packets': 'total_fwd_packets',
        'tot_bwd_pkts': 'total_bwd_packets',
        'total_backward_packets': 'total_bwd_packets',
        'totlen_fwd_pkts': 'total_fwd_bytes',
        'total_length_of_fwd_packets': 'total_fwd_bytes',
        'totlen_bwd_pkts': 'total_bwd_bytes',
        'total_length_of_bwd_packets': 'total_bwd_bytes',
        'flow_byts_s': 'flow_bytes_per_sec',
        'flow_bytes_s': 'flow_bytes_per_sec',
        'flow_pkts_s': 'flow_packets_per_sec',
        'flow_packets_s': 'flow_packets_per_sec',
        'syn_flag_cnt': 'syn_flag_count',
        'ack_flag_cnt': 'ack_flag_count',
        'rst_flag_cnt': 'rst_flag_count'
    }
    for old_col, new_col in column_aliases.items():
        if old_col in df.columns and new_col not in df.columns:
            df[new_col] = df[old_col]

    # Encode protocol if present as string
    if 'protocol' in df.columns:
        df['protocol_num'] = df['protocol'].apply(lambda x: PROTOCOL_MAP.get(str(x).upper(), 6))
    elif 'protocol_num' not in df.columns:
        df['protocol_num'] = 6

    # Fill defaults for any missing expected features
    for col in FEATURE_COLUMNS:
        if col not in df.columns:
            df[col] = 0.0

    # Replace infinities with NaN then impute with column median or max
    df = df.replace([np.inf, -np.inf], np.nan)
    for col in FEATURE_COLUMNS:
        if df[col].isna().any():
            median_val = df[col].median()
            df[col] = df[col].fillna(median_val if not np.isnan(median_val) else 0.0)

    return df

def extract_feature_vector(record: Dict[str, Any]) -> List[float]:
    """
    Extracts ordered feature vector for a single log record dictionary.
    """
    proto = record.get('protocol', 'TCP')
    proto_num = PROTOCOL_MAP.get(str(proto).upper(), 6)

    return [
        float(record.get('dest_port', 0)),
        float(record.get('flow_duration', 0.0)),
        float(record.get('total_fwd_packets', 0)),
        float(record.get('total_bwd_packets', 0)),
        float(record.get('total_fwd_bytes', 0)),
        float(record.get('total_bwd_bytes', 0)),
        float(record.get('flow_bytes_per_sec', 0.0)),
        float(record.get('flow_packets_per_sec', 0.0)),
        float(record.get('syn_flag_count', 0)),
        float(record.get('ack_flag_count', 0)),
        float(record.get('rst_flag_count', 0)),
        float(record.get('failed_login_attempts', 0)),
        float(proto_num)
    ]
