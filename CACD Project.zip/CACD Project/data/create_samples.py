import os
import json

samples_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "test_samples")
os.makedirs(samples_dir, exist_ok=True)

# 1. Suricata EVE JSON
eve_data = [
    {
        "timestamp": "2026-10-08 08:00:00",
        "src_ip": "192.168.1.105",
        "dest_ip": "10.0.0.1",
        "src_port": 54321,
        "dest_port": 80,
        "proto": "TCP",
        "event_type": "flow",
        "flow": {
            "age": 3.2,
            "pkts_toserver": 15,
            "pkts_toclient": 20,
            "bytes_toserver": 1200,
            "bytes_toclient": 2400
        }
    },
    {
        "timestamp": "2026-10-08 08:01:00",
        "src_ip": "172.16.0.45",
        "dest_ip": "10.0.0.5",
        "src_port": 40000,
        "dest_port": 80,
        "proto": "TCP",
        "event_type": "flow",
        "flow": {
            "age": 0.8,
            "pkts_toserver": 2500,
            "pkts_toclient": 0,
            "bytes_toserver": 900000,
            "bytes_toclient": 0
        }
    }
]
with open(os.path.join(samples_dir, "sample_suricata_eve.json"), "w") as f:
    json.dump(eve_data, f, indent=2)

# 2. Linux SSH auth log
with open(os.path.join(samples_dir, "sample_ssh_bruteforce.log"), "w") as f:
    for i in range(1, 8):
        f.write(f"Oct 08 08:10:0{i} soc-server sshd[220{i}]: Failed password for invalid user admin from 203.0.113.88 port {50000+i} ssh2\n")

# 3. Apache access log with SQL injection
with open(os.path.join(samples_dir, "sample_apache_sqli.log"), "w") as f:
    f.write('198.51.100.145 - - [08/Oct/2026:08:15:00 +0000] "GET /login.php?user=admin%27%20OR%201=1-- HTTP/1.1" 200 4520\n')
    f.write('198.51.100.145 - - [08/Oct/2026:08:15:02 +0000] "GET /admin/db.php?id=1%20UNION%20SELECT%20null,password%20FROM%20users HTTP/1.1" 200 6890\n')
    f.write('192.168.1.55 - - [08/Oct/2026:08:15:05 +0000] "GET /index.html HTTP/1.1" 200 1250\n')

# 4. Windows Event XML
with open(os.path.join(samples_dir, "sample_windows_event.xml"), "w") as f:
    f.write("""<Events>
  <Event>
    <EventID>4625</EventID>
    <IpAddress>198.51.100.99</IpAddress>
    <TargetUserName>Administrator</TargetUserName>
    <Status>0xC000006D</Status>
  </Event>
  <Event>
    <EventID>4624</EventID>
    <IpAddress>192.168.1.45</IpAddress>
    <TargetUserName>analyst</TargetUserName>
    <Status>0x0</Status>
  </Event>
</Events>""")

print(f"Sample test files created in {samples_dir}")
