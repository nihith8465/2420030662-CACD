"""
Database Seeder: Ingests realistic sample logs and creates initial alerts and audits.
"""
import os
import sys

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

import pandas as pd
from src.database import init_db, run_integrity_audit
from src.alert_manager import process_and_record_log

def seed_database(limit: int = 150):
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    csv_path = os.path.join(base_dir, "data", "sample_logs.csv")
    db_path = os.path.join(base_dir, "data", "security_system.db")

    print("[*] Initializing SQLite database...")
    init_db(db_path)

    if not os.path.exists(csv_path):
        print("[!] Sample logs CSV not found. Run models/train_model.py first.")
        return

    df = pd.read_csv(csv_path)
    subset = df.head(limit)

    print(f"[*] Ingesting {len(subset)} initial security events...")
    attack_count = 0
    for _, row in subset.iterrows():
        rec = row.to_dict()
        res = process_and_record_log(rec)
        if res.get('alert'):
            attack_count += 1

    print(f"[*] Ingestion complete! Total ingested: {len(subset)}, Alerts generated: {attack_count}")
    
    # Run initial integrity check
    audit_res = run_integrity_audit(db_path)
    print(f"[*] Initial SHA-512 Audit Result: {audit_res['status']} ({audit_res['passed']}/{audit_res['total_checked']} verified)")

if __name__ == "__main__":
    seed_database()
