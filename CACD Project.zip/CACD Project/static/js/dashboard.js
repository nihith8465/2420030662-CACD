/**
 * Dashboard Charts & Dynamic Metrics Initialization (Chart.js)
 */

let timelineChart = null;
let categoryChart = null;
let topIpsChart = null;
let severityChart = null;

const THEME_COLORS = {
    cyan: '#06b6d4',
    blue: '#3b82f6',
    purple: '#8b5cf6',
    critical: '#ef4444',
    high: '#f97316',
    medium: '#eab308',
    low: '#10b981',
    grid: '#374151',
    text: '#9ca3af'
};

async function fetchDashboardStats() {
    try {
        const res = await fetch('/api/stats');
        return await res.json();
    } catch (e) {
        console.error('Failed to load dashboard statistics:', e);
        return null;
    }
}

function initTimelineChart(data) {
    const ctx = document.getElementById('timelineChart')?.getContext('2d');
    if (!ctx) return;

    if (timelineChart) timelineChart.destroy();

    timelineChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: data.labels,
            datasets: [
                {
                    label: 'Total Events',
                    data: data.events,
                    borderColor: THEME_COLORS.cyan,
                    backgroundColor: 'rgba(6, 182, 212, 0.1)',
                    fill: true,
                    tension: 0.35,
                    borderWidth: 2
                },
                {
                    label: 'Threat Alerts',
                    data: data.threats,
                    borderColor: THEME_COLORS.critical,
                    backgroundColor: 'rgba(239, 68, 68, 0.1)',
                    fill: true,
                    tension: 0.35,
                    borderWidth: 2
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { labels: { color: THEME_COLORS.text } }
            },
            scales: {
                x: {
                    grid: { color: 'rgba(55, 65, 81, 0.4)' },
                    ticks: { color: THEME_COLORS.text }
                },
                y: {
                    grid: { color: 'rgba(55, 65, 81, 0.4)' },
                    ticks: { color: THEME_COLORS.text }
                }
            }
        }
    });
}

function initAttackCategoryChart(dist) {
    const ctx = document.getElementById('attackCategoryChart')?.getContext('2d');
    if (!ctx) return;

    if (categoryChart) categoryChart.destroy();

    const labels = Object.keys(dist);
    const counts = Object.values(dist);

    const palette = [
        THEME_COLORS.low,
        THEME_COLORS.critical,
        THEME_COLORS.medium,
        THEME_COLORS.high,
        THEME_COLORS.purple,
        THEME_COLORS.blue
    ];

    categoryChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: labels,
            datasets: [{
                data: counts,
                backgroundColor: palette.slice(0, labels.length),
                borderWidth: 1,
                borderColor: '#1f2937'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: { color: THEME_COLORS.text, boxWidth: 12, padding: 12 }
                }
            },
            cutout: '65%'
        }
    });
}

function initTopIpsChart(topIps) {
    const ctx = document.getElementById('topIpsChart')?.getContext('2d');
    if (!ctx) return;

    if (topIpsChart) topIpsChart.destroy();

    const labels = topIps.map(item => item.ip);
    const data = topIps.map(item => item.count);

    topIpsChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels.length ? labels : ['None'],
            datasets: [{
                label: 'Threat Count',
                data: data.length ? data : [0],
                backgroundColor: 'rgba(239, 68, 68, 0.8)',
                borderColor: THEME_COLORS.critical,
                borderRadius: 6,
                borderWidth: 1
            }]
        },
        options: {
            indexAxis: 'y',
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false }
            },
            scales: {
                x: {
                    grid: { color: 'rgba(55, 65, 81, 0.4)' },
                    ticks: { color: THEME_COLORS.text }
                },
                y: {
                    grid: { display: false },
                    ticks: { color: '#f3f4f6' }
                }
            }
        }
    });
}

function initSeverityChart(dist) {
    const ctx = document.getElementById('severityChart')?.getContext('2d');
    if (!ctx) return;

    if (severityChart) severityChart.destroy();

    const severities = ['LOW', 'MEDIUM', 'HIGH', 'CRITICAL'];
    const counts = severities.map(s => dist[s] || 0);

    severityChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: severities,
            datasets: [{
                label: 'Alerts',
                data: counts,
                backgroundColor: [
                    'rgba(16, 185, 129, 0.7)',
                    'rgba(234, 179, 8, 0.7)',
                    'rgba(249, 115, 22, 0.7)',
                    'rgba(239, 68, 68, 0.7)'
                ],
                borderColor: [
                    THEME_COLORS.low,
                    THEME_COLORS.medium,
                    THEME_COLORS.high,
                    THEME_COLORS.critical
                ],
                borderWidth: 1,
                borderRadius: 6
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false }
            },
            scales: {
                x: {
                    grid: { display: false },
                    ticks: { color: THEME_COLORS.text }
                },
                y: {
                    grid: { color: 'rgba(55, 65, 81, 0.4)' },
                    ticks: { color: THEME_COLORS.text }
                }
            }
        }
    });
}

async function refreshDashboardData() {
    const stats = await fetchDashboardStats();
    if (!stats) return;

    initTimelineChart(stats.timeline);
    initAttackCategoryChart(stats.threat_dist);
    initTopIpsChart(stats.top_ips);
    initSeverityChart(stats.severity_dist);
}

let streamInterval = null;
let streamParams = {};
let streamCounter = 0;
let streamMax = 0;

function showStreamConfigModal() {
    document.getElementById('streamConfigModal').style.display = 'flex';
}

function closeStreamConfigModal() {
    document.getElementById('streamConfigModal').style.display = 'none';
}

function toggleTrafficStream() {
    if (!streamInterval) {
        showStreamConfigModal();
    } else {
        stopTrafficStream();
    }
}

function stopTrafficStream() {
    if (streamInterval) {
        clearInterval(streamInterval);
        streamInterval = null;
    }
    const btn = document.getElementById('streamToggleBtn');
    btn.innerText = '📡 Start Live Stream (Demo)';
    btn.className = 'btn btn-secondary';
    btn.style.borderColor = 'var(--accent-cyan)';
}

function startConfiguredStream(e) {
    e.preventDefault();
    closeStreamConfigModal();

    streamParams = {
        attack_type: document.getElementById('stream_attack_type').value,
        target_ip: document.getElementById('stream_target_ip').value,
        source_ip: document.getElementById('stream_source_ip').value
    };
    const speed = parseInt(document.getElementById('stream_speed').value) || 2000;
    streamMax = parseInt(document.getElementById('stream_limit').value) || 0;
    streamCounter = 0;

    const btn = document.getElementById('streamToggleBtn');
    btn.innerText = '⏹️ Stop Live Stream';
    btn.className = 'btn btn-danger';

    streamInterval = setInterval(fetchNextStreamEvent, speed);
    fetchNextStreamEvent();
}

async function fetchNextStreamEvent() {
    try {
        const query = new URLSearchParams(streamParams).toString();
        const res = await fetch(`/api/stream/next?${query}`);
        const data = await res.json();
        if (data.success) {
            streamCounter++;
            if (data.alert) {
                showStreamToast(data.alert);
            }
            await refreshDashboardData();

            if (streamMax > 0 && streamCounter >= streamMax) {
                stopTrafficStream();
                alert(`Stream completed: successfully injected and processed ${streamCounter} user-configured security flows.`);
            }
        }
    } catch (e) {
        console.error('Stream event error:', e);
    }
}

function showStreamToast(alert) {
    const toast = document.getElementById('liveStreamToast');
    const badge = document.getElementById('toastBadge');
    const msg = document.getElementById('toastMessage');

    badge.innerText = alert.attack_type;
    msg.innerText = `Source IP: ${alert.source_ip} -> Target: ${alert.dest_ip} (${alert.severity} Severity)`;

    toast.style.display = 'block';
    setTimeout(() => {
        toast.style.display = 'none';
    }, 3500);
}

document.addEventListener('DOMContentLoaded', () => {
    refreshDashboardData();
    // Auto-refresh every 30 seconds
    setInterval(refreshDashboardData, 30000);
});
