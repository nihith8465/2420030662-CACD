/**
 * SHA-512 Cryptographic Integrity Audit Operations
 */

async function runIntegrityAudit() {
    try {
        const res = await fetch('/api/integrity/verify', { method: 'POST' });
        const data = await res.json();
        displayAuditResult(data);
    } catch (e) {
        alert('Failed to execute integrity audit: ' + e);
    }
}

function showTamperModal() {
    document.getElementById('tamperModal').style.display = 'flex';
}

function closeTamperModal() {
    document.getElementById('tamperModal').style.display = 'none';
}

function simulateTampering() {
    showTamperModal();
}

async function submitConfiguredTamper(e) {
    e.preventDefault();
    closeTamperModal();

    const logId = document.getElementById('tamper_log_id').value;
    const fieldName = document.getElementById('tamper_field').value;
    const newValue = document.getElementById('tamper_new_value').value;

    try {
        const res = await fetch('/api/integrity/simulate-tamper', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ log_id: logId, field_name: fieldName, new_value: newValue })
        });
        const data = await res.json();
        if (data.success) {
            alert(data.message);
            // Automatically run audit to demonstrate detection
            await runIntegrityAudit();
        } else {
            alert('Tampering failed: ' + data.error);
        }
    } catch (e) {
        alert('Simulation failed: ' + e);
    }
}

async function repairDatabase() {
    if (!confirm('This will recompute and re-sign SHA-512 hashes for all records in the database, restoring verified status. Proceed?')) {
        return;
    }

    try {
        const res = await fetch('/api/integrity/repair', { method: 'POST' });
        const data = await res.json();
        alert(`Successfully re-signed ${data.repaired_count} records. Integrity restored.`);
        displayAuditResult(data.audit);
    } catch (e) {
        alert('Repair failed: ' + e);
    }
}

function displayAuditResult(audit) {
    const card = document.getElementById('auditResultCard');
    const badge = document.getElementById('auditStatusBadge');
    const totalEl = document.getElementById('auditTotalChecked');
    const passedEl = document.getElementById('auditPassed');
    const tamperedEl = document.getElementById('auditTampered');
    const tamperedBox = document.getElementById('tamperedDetailsBox');
    const tableContainer = document.getElementById('tamperedTableContainer');

    totalEl.innerText = audit.total_checked;
    passedEl.innerText = audit.passed;
    tamperedEl.innerText = audit.tampered_count;

    if (audit.status === 'PASSED') {
        badge.className = 'badge badge-passed';
        badge.innerText = 'INTEGRITY VERIFIED';
        tamperedBox.style.display = 'none';
    } else {
        badge.className = 'badge badge-compromised';
        badge.innerText = 'TAMPERING DETECTED (BREACH)';

        // Render details of tampered records
        let html = `
            <table class="cyber-table" style="margin-top: 0.5rem;">
                <thead>
                    <tr>
                        <th>Record ID</th>
                        <th>Timestamp</th>
                        <th>Source IP</th>
                        <th>Stored SHA-512</th>
                        <th>Calculated SHA-512</th>
                    </tr>
                </thead>
                <tbody>
        `;
        audit.tampered_details.forEach(item => {
            html += `
                <tr>
                    <td>#${item.id}</td>
                    <td>${item.timestamp}</td>
                    <td><code>${item.source_ip}</code></td>
                    <td><span class="hash-badge" style="color:#ef4444;">${item.stored_hash.substring(0, 16)}...</span></td>
                    <td><span class="hash-badge" style="color:#34d399;">${item.computed_hash.substring(0, 16)}...</span></td>
                </tr>
            `;
        });
        html += `</tbody></table>`;
        tableContainer.innerHTML = html;
        tamperedBox.style.display = 'block';
    }

    card.style.display = 'block';
    card.scrollIntoView({ behavior: 'smooth' });
}
