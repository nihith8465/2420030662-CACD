# AI-Based Security Log Analysis and Threat Detection Using Machine Learning

An end-to-end cybersecurity threat detection and log analysis platform built with Python, Scikit-learn, Flask, Chart.js, SQLite, and SHA-512 cryptographic hashing. Designed according to the **CIC-IDS2017 Intrusion Detection Evaluation Dataset** standards.

---

## 🎯 Objectives
- **Universal Multi-Format Ingestion**: Ingests `.csv`, `.tsv`, `.json`, `.jsonl` (Suricata EVE), `.log`, `.txt` (Linux SSH auth & Apache web logs), `.pcap`, `.pcapng` (Scapy packet capture), and `.xml` (Windows Event logs).
- **Multi-Class AI Threat Classification**: Detects **BENIGN**, **DoS/DDoS**, **Brute Force**, **PortScan**, **Web Attack**, and **Botnet** with **99.97% Accuracy** using Random Forest.
- **Explainable Hybrid Engine**: Combines ML probabilities with deterministic rule heuristics and Gini feature importances.
- **Cryptographic Blockchain-Style Audit Ledger (SHA-512)**: Chains records sequentially (`SHA-512(record + prev_hash)`). Guaranteed tamper-evidence and non-repudiation.
- **Active Defense & Threat Containment (SOAR)**: Automated IP quarantine hub with live firewall rule generation (Linux `iptables` & Windows `netsh advfirewall`).
- **Live SOC Traffic Streaming Simulator**: Real-time traffic stream mode with animated Chart.js graphs and live toast alerts for presentations.
- **Executive Threat & Compliance Audit Report**: Clean, printable executive audit report (`/report`).

---

## 🔄 Project Architecture & Flow

```
+-------------------------------------------------------------+
|                Security & Network Event Logs                |
|           (CIC-IDS2017 Flows / Ingested CSVs)               |
+-------------------------------------------------------------+
                              |
                              v
+-------------------------------------------------------------+
|                     Data Preprocessing                      |
|         (Handle NaN/Inf, Protocol Encoding, Scaling)         |
+-------------------------------------------------------------+
                              |
                              v
+-------------------------------------------------------------+
|                      Feature Extraction                     |
|    (Ports, Duration, Packet Counts, Byte Rates, TCP Flags)  |
+-------------------------------------------------------------+
                              |
                              v
+-------------------------------------------------------------+
|                 Hybrid Threat Detection Engine              |
|        Machine Learning Model    +    Rule-Based Engine     |
|   (Random Forest / Decision Tree) | (Explainable Signatures) |
+-------------------------------------------------------------+
                              |
                              v
+-------------------------------------------------------------+
|                     Alert Generation                        |
|  (Severity: Low/Medium/High/Critical, Source/Target, Audit) |
+-------------------------------------------------------------+
                              |
                              v
+-------------------------------------------------------------+
|                  SOC Web Dashboard (Flask)                  |
|    - Traffic & Threat Timeline       - Attack Categories    |
|    - Top Threat Source IPs           - Incident Response    |
+-------------------------------------------------------------+
                              |
                              v
+-------------------------------------------------------------+
|            Cryptographic Log Integrity (SHA-512)            |
|   - Deterministic Canonical Record Hashing                  |
|   - Automated Audit & Tamper Detection Engine               |
|   - Live Tampering Simulation & Non-Repudiation Proof      |
+-------------------------------------------------------------+
```

---

## 📊 Machine Learning Model Benchmarks

Trained on 15,000 stratified samples mirroring CIC-IDS2017 distributions (80/20 train/test split):

| Model Architecture | Accuracy | Precision (Weighted) | Recall (Weighted) | F1-Score (Weighted) | Status |
| :--- | :---: | :---: | :---: | :---: | :---: |
| **Random Forest** | **99.97%** | **99.97%** | **99.97%** | **99.97%** | **Primary (Deployed)** |
| **Decision Tree** | 99.80% | 99.80% | 99.80% | 99.80% | Evaluated |
| **Logistic Regression** | 99.37% | 99.37% | 99.37% | 99.36% | Evaluated |

- **False Positive Rate (Benign misclassified as attack)**: `< 0.05%`
- **Serialized Model Artifacts**: Located in `models/` (`model.joblib`, `scaler.joblib`, `label_encoder.joblib`, `evaluation_metrics.json`).

---

## 🔐 Cryptographic Integrity & Tamper Detection (SHA-512)

1. **Canonical Normalization**: Standardizes timestamp, IP addresses, ports, protocol, packet counts, byte metrics, and classification label.
2. **Digest Generation**: Evaluates `hashlib.sha512(canonical_str.encode('utf-8')).hexdigest()` to produce a 128-hex-character digest before insertion.
3. **Audit Verification**:
   - Re-hashes all database records on demand or schedule.
   - Flags any record whose recalculated hash diverges from the stored hash.
4. **Tamper Sandbox**:
   - The dashboard includes a **"Simulate Tampering Breach"** action that intentionally alters a record in SQLite to demonstrate real-time tamper detection in front of reviewers.

---

## 💻 Tech Stack
- **Backend**: Python 3, Flask, SQLite3
- **Data & ML**: Pandas, NumPy, Scikit-learn, Joblib
- **Security & Crypto**: `hashlib` (SHA-512)
- **Frontend**: HTML5, CSS3 (Modern Dark SOC Aesthetic), Chart.js (v4.4), JavaScript

---

## 🚀 Installation and Setup

### 1. Prerequisites
- Python 3.10+ (Tested up to Python 3.14)
- `pip` package manager

### 2. Install Dependencies
```bash
pip install -r requirements.txt
```

### 3. (Optional) Retrain Machine Learning Models
```bash
python models/train_model.py
```

### 4. (Optional) Seed Database with Benchmark Data
```bash
python data/seed_data.py
```

### 5. Launch the SOC Web Application
```bash
python app.py
```
Open your web browser and navigate to:
```
http://127.0.0.1:5000
```

---

## 🧪 Running Automated Tests
Run the comprehensive test suite (preprocessing, ML classifier, rule engine, SHA-512 integrity, and Flask endpoints):
```bash
python -m unittest tests/test_system.py
```

---

## 📁 Directory Structure
```
CACD Project/
├── app.py                          # Flask application routes and API endpoints
├── requirements.txt                # Project dependencies
├── README.md                       # Documentation and usage guide
│
├── data/
│   ├── sample_logs.csv             # CIC-IDS2017 compliant dataset (15,000 samples)
│   ├── seed_data.py                # Database seeder utility
│   └── security_system.db          # SQLite database (logs, alerts, audit trails)
│
├── models/
│   ├── train_model.py              # ML training and evaluation pipeline
│   ├── model.joblib                # Serialized Random Forest model
│   ├── scaler.joblib               # StandardScaler feature transformer
│   ├── label_encoder.joblib        # LabelEncoder for attack categories
│   └── evaluation_metrics.json     # Benchmark stats & confusion matrix
│
├── src/
│   ├── preprocessor.py             # Data cleaning, null handling & feature vector extraction
│   ├── rule_engine.py              # Heuristic rules for explainable security alerts
│   ├── classifier.py               # Hybrid ML + Rule threat classification engine
│   ├── alert_manager.py            # Alert ingestion and severity stratification
│   ├── integrity_service.py        # SHA-512 cryptographic hashing and audit verification
│   └── database.py                 # SQLite database schema, CRUD, and audit routines
│
├── static/
│   ├── css/
│   │   └── style.css               # Modern dark SOC cybersecurity interface
│   └── js/
│       ├── dashboard.js            # Real-time Chart.js visualizers
│       └── integrity.js            # Interactive SHA-512 audit and tamper testing
│
├── templates/
│   ├── base.html                   # Master layout and SOC navigation
│   ├── dashboard.html              # Main SOC analytics dashboard
│   ├── logs.html                   # Filterable log explorer with SHA-512 modal
│   ├── alerts.html                 # Incident feed with severity filtering and triage
│   ├── analyze.html                # Batch CSV ingestion & single flow sandbox
│   ├── integrity.html              # SHA-512 cryptographic verification center
│   └── metrics.html                # Model scorecard, confusion matrix & benchmark report
│
└── tests/
    └── test_system.py              # Automated unit and integration test suite
```
