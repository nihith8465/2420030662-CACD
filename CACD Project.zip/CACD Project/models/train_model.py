"""
Machine Learning Training Pipeline for Network Intrusion and Security Threat Detection.
Generates CIC-IDS2017 aligned training data, trains Random Forest, Decision Tree,
and Logistic Regression classifiers, and exports evaluation metrics and serialized models.
"""
import os
import json
import numpy as np
import pandas as pd
import joblib

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, precision_recall_fscore_support, confusion_matrix, classification_report

FEATURE_COLUMNS = [
    'dest_port',
    'flow_duration',
    'total_fwd_packets',
    'total_bwd_packets',
    'total_fwd_bytes',
    'total_bwd_bytes',
    'flow_bytes_per_sec',
    'flow_packets_per_sec',
    'syn_flag_count',
    'ack_flag_count',
    'rst_flag_count',
    'failed_login_attempts',
    'protocol_num'
]

ATTACK_CLASSES = ['BENIGN', 'DoS/DDoS', 'PortScan', 'Brute Force', 'Web Attack', 'Botnet']

def generate_synthetic_cicids2017_dataset(n_samples: int = 12000, random_state: int = 42) -> pd.DataFrame:
    """
    Generates a high-fidelity synthetic benchmark dataset modeled on CIC-IDS2017 traffic characteristics.
    """
    np.random.seed(random_state)
    records = []

    # Distribution of classes: ~40% Benign, ~20% DoS/DDoS, ~15% PortScan, ~10% Brute Force, ~10% Web Attack, ~5% Botnet
    class_weights = [0.40, 0.20, 0.15, 0.10, 0.10, 0.05]
    samples_per_class = np.random.multinomial(n_samples, class_weights)

    # 1. BENIGN Traffic
    count = samples_per_class[0]
    for _ in range(count):
        port = np.random.choice([80, 443, 53, 8080, 22, 445, 123, 5353])
        duration = np.random.exponential(scale=30.0) + 0.1
        fwd_pkts = np.random.randint(1, 40)
        bwd_pkts = np.random.randint(1, 40)
        fwd_bytes = fwd_pkts * np.random.randint(50, 800)
        bwd_bytes = bwd_pkts * np.random.randint(50, 1400)
        f_bytes_s = (fwd_bytes + bwd_bytes) / duration
        f_pkts_s = (fwd_pkts + bwd_pkts) / duration
        syn_cnt = 1 if np.random.rand() > 0.3 else 0
        ack_cnt = syn_cnt
        rst_cnt = 0 if np.random.rand() > 0.05 else 1
        failed_logins = 0 if np.random.rand() > 0.03 else 1
        proto = 6 if port != 53 and port != 123 else 17

        records.append({
            'timestamp': '2026-09-03 10:00:00',
            'source_ip': f"192.168.1.{np.random.randint(10, 200)}",
            'dest_ip': f"10.0.0.{np.random.randint(2, 50)}",
            'dest_port': port,
            'flow_duration': duration,
            'total_fwd_packets': fwd_pkts,
            'total_bwd_packets': bwd_pkts,
            'total_fwd_bytes': fwd_bytes,
            'total_bwd_bytes': bwd_bytes,
            'flow_bytes_per_sec': f_bytes_s,
            'flow_packets_per_sec': f_pkts_s,
            'syn_flag_count': syn_cnt,
            'ack_flag_count': ack_cnt,
            'rst_flag_count': rst_cnt,
            'failed_login_attempts': failed_logins,
            'protocol_num': proto,
            'label': 'BENIGN'
        })

    # 2. DoS / DDoS Traffic
    count = samples_per_class[1]
    for _ in range(count):
        port = np.random.choice([80, 443, 8080, 53])
        duration = np.random.uniform(0.01, 5.0)
        fwd_pkts = np.random.randint(500, 5000)
        bwd_pkts = np.random.randint(0, 10)
        fwd_bytes = fwd_pkts * np.random.randint(40, 200)
        bwd_bytes = bwd_pkts * 60
        f_bytes_s = (fwd_bytes + bwd_bytes) / duration
        f_pkts_s = (fwd_pkts + bwd_pkts) / duration
        syn_cnt = np.random.randint(50, 500)
        ack_cnt = np.random.randint(0, 5)
        rst_cnt = np.random.randint(0, 10)
        failed_logins = 0
        proto = np.random.choice([6, 17])

        records.append({
            'timestamp': '2026-09-03 10:15:00',
            'source_ip': f"172.16.0.{np.random.randint(2, 250)}",
            'dest_ip': "10.0.0.5",
            'dest_port': port,
            'flow_duration': duration,
            'total_fwd_packets': fwd_pkts,
            'total_bwd_packets': bwd_pkts,
            'total_fwd_bytes': fwd_bytes,
            'total_bwd_bytes': bwd_bytes,
            'flow_bytes_per_sec': f_bytes_s,
            'flow_packets_per_sec': f_pkts_s,
            'syn_flag_count': syn_cnt,
            'ack_flag_count': ack_cnt,
            'rst_flag_count': rst_cnt,
            'failed_login_attempts': failed_logins,
            'protocol_num': proto,
            'label': 'DoS/DDoS'
        })

    # 3. PortScan Traffic
    count = samples_per_class[2]
    for _ in range(count):
        port = np.random.randint(1, 65535)
        duration = np.random.uniform(0.001, 0.5)
        fwd_pkts = np.random.randint(1, 5)
        bwd_pkts = 0 if np.random.rand() > 0.2 else np.random.randint(1, 3)
        fwd_bytes = fwd_pkts * 44
        bwd_bytes = bwd_pkts * 40
        f_bytes_s = (fwd_bytes + bwd_bytes) / duration
        f_pkts_s = (fwd_pkts + bwd_pkts) / duration
        syn_cnt = np.random.randint(1, 10)
        ack_cnt = 0
        rst_cnt = np.random.randint(1, 5)
        failed_logins = 0
        proto = 6

        records.append({
            'timestamp': '2026-09-03 10:30:00',
            'source_ip': f"198.51.100.{np.random.randint(5, 50)}",
            'dest_ip': "10.0.0.10",
            'dest_port': port,
            'flow_duration': duration,
            'total_fwd_packets': fwd_pkts,
            'total_bwd_packets': bwd_pkts,
            'total_fwd_bytes': fwd_bytes,
            'total_bwd_bytes': bwd_bytes,
            'flow_bytes_per_sec': f_bytes_s,
            'flow_packets_per_sec': f_pkts_s,
            'syn_flag_count': syn_cnt,
            'ack_flag_count': ack_cnt,
            'rst_flag_count': rst_cnt,
            'failed_login_attempts': failed_logins,
            'protocol_num': proto,
            'label': 'PortScan'
        })

    # 4. Brute Force (SSH/FTP)
    count = samples_per_class[3]
    for _ in range(count):
        port = np.random.choice([21, 22, 3389])
        duration = np.random.uniform(0.5, 10.0)
        fwd_pkts = np.random.randint(10, 80)
        bwd_pkts = np.random.randint(8, 70)
        fwd_bytes = fwd_pkts * np.random.randint(60, 200)
        bwd_bytes = bwd_pkts * np.random.randint(60, 200)
        f_bytes_s = (fwd_bytes + bwd_bytes) / duration
        f_pkts_s = (fwd_pkts + bwd_pkts) / duration
        syn_cnt = np.random.randint(1, 6)
        ack_cnt = syn_cnt
        rst_cnt = np.random.randint(0, 3)
        failed_logins = np.random.randint(3, 20)
        proto = 6

        records.append({
            'timestamp': '2026-09-03 10:45:00',
            'source_ip': f"203.0.113.{np.random.randint(10, 80)}",
            'dest_ip': "10.0.0.2",
            'dest_port': port,
            'flow_duration': duration,
            'total_fwd_packets': fwd_pkts,
            'total_bwd_packets': bwd_pkts,
            'total_fwd_bytes': fwd_bytes,
            'total_bwd_bytes': bwd_bytes,
            'flow_bytes_per_sec': f_bytes_s,
            'flow_packets_per_sec': f_pkts_s,
            'syn_flag_count': syn_cnt,
            'ack_flag_count': ack_cnt,
            'rst_flag_count': rst_cnt,
            'failed_login_attempts': failed_logins,
            'protocol_num': proto,
            'label': 'Brute Force'
        })

    # 5. Web Attack (SQLi, XSS, Command Injection)
    count = samples_per_class[4]
    for _ in range(count):
        port = np.random.choice([80, 443, 8080])
        duration = np.random.uniform(0.2, 5.0)
        fwd_pkts = np.random.randint(5, 30)
        bwd_pkts = np.random.randint(3, 25)
        fwd_bytes = fwd_pkts * np.random.randint(300, 1500) # larger suspicious web payloads
        bwd_bytes = bwd_pkts * np.random.randint(200, 800)
        f_bytes_s = (fwd_bytes + bwd_bytes) / duration
        f_pkts_s = (fwd_pkts + bwd_pkts) / duration
        syn_cnt = np.random.randint(1, 5)
        ack_cnt = syn_cnt
        rst_cnt = np.random.randint(1, 4)
        failed_logins = 0
        proto = 6

        records.append({
            'timestamp': '2026-09-03 11:00:00',
            'source_ip': f"198.51.100.{np.random.randint(100, 200)}",
            'dest_ip': "10.0.0.8",
            'dest_port': port,
            'flow_duration': duration,
            'total_fwd_packets': fwd_pkts,
            'total_bwd_packets': bwd_pkts,
            'total_fwd_bytes': fwd_bytes,
            'total_bwd_bytes': bwd_bytes,
            'flow_bytes_per_sec': f_bytes_s,
            'flow_packets_per_sec': f_pkts_s,
            'syn_flag_count': syn_cnt,
            'ack_flag_count': ack_cnt,
            'rst_flag_count': rst_cnt,
            'failed_login_attempts': failed_logins,
            'protocol_num': proto,
            'label': 'Web Attack'
        })

    # 6. Botnet C2 Communication
    count = samples_per_class[5]
    for _ in range(count):
        port = np.random.choice([6667, 1337, 31337, 61234, 65432])
        duration = np.random.uniform(10.0, 120.0) # periodic long beaconing
        fwd_pkts = np.random.randint(10, 100)
        bwd_pkts = np.random.randint(10, 100)
        fwd_bytes = fwd_pkts * np.random.randint(60, 150)
        bwd_bytes = bwd_pkts * np.random.randint(60, 150)
        f_bytes_s = (fwd_bytes + bwd_bytes) / duration
        f_pkts_s = (fwd_pkts + bwd_pkts) / duration
        syn_cnt = np.random.randint(1, 3)
        ack_cnt = syn_cnt
        rst_cnt = 0
        failed_logins = 0
        proto = 6

        records.append({
            'timestamp': '2026-09-03 11:15:00',
            'source_ip': f"192.168.1.{np.random.randint(15, 30)}",
            'dest_ip': f"185.220.101.{np.random.randint(1, 50)}",
            'dest_port': port,
            'flow_duration': duration,
            'total_fwd_packets': fwd_pkts,
            'total_bwd_packets': bwd_pkts,
            'total_fwd_bytes': fwd_bytes,
            'total_bwd_bytes': bwd_bytes,
            'flow_bytes_per_sec': f_bytes_s,
            'flow_packets_per_sec': f_pkts_s,
            'syn_flag_count': syn_cnt,
            'ack_flag_count': ack_cnt,
            'rst_flag_count': rst_cnt,
            'failed_login_attempts': failed_logins,
            'protocol_num': proto,
            'label': 'Botnet'
        })

    df = pd.DataFrame(records)
    # Shuffle
    df = df.sample(frac=1.0, random_state=random_state).reset_index(drop=True)
    return df

def train_and_evaluate_models():
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    data_dir = os.path.join(base_dir, "data")
    models_dir = os.path.join(base_dir, "models")
    os.makedirs(data_dir, exist_ok=True)
    os.makedirs(models_dir, exist_ok=True)

    print("[*] Generating CIC-IDS2017 compliant dataset...")
    df = generate_synthetic_cicids2017_dataset(n_samples=15000, random_state=42)

    # Save CSV benchmark for user / testing
    sample_csv_path = os.path.join(data_dir, "sample_logs.csv")
    df.to_csv(sample_csv_path, index=False)
    print(f"[*] Saved sample dataset to {sample_csv_path}")

    # Feature matrix X and labels y
    X = df[FEATURE_COLUMNS].values
    y_raw = df['label'].values

    # Encode labels
    label_encoder = LabelEncoder()
    y = label_encoder.fit_transform(y_raw)
    class_names = list(label_encoder.classes_)

    # Train / Test split (80/20)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42, stratify=y
    )

    # Feature scaling
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    print("[*] Training candidate classifiers...")
    models = {
        "Random Forest": RandomForestClassifier(n_estimators=100, max_depth=15, random_state=42, n_jobs=-1),
        "Decision Tree": DecisionTreeClassifier(max_depth=12, random_state=42),
        "Logistic Regression": LogisticRegression(max_iter=1000, random_state=42)
    }

    comparison_results = {}
    best_name = None
    best_f1 = -1.0
    best_model = None

    for name, model in models.items():
        print(f"    -> Training {name}...")
        model.fit(X_train_scaled, y_train)
        y_pred = model.predict(X_test_scaled)

        acc = accuracy_score(y_test, y_pred)
        prec, rec, f1, _ = precision_recall_fscore_support(y_test, y_pred, average='weighted', zero_division=0)

        comparison_results[name] = {
            "accuracy": round(float(acc) * 100, 2),
            "precision": round(float(prec) * 100, 2),
            "recall": round(float(rec) * 100, 2),
            "f1_score": round(float(f1) * 100, 2)
        }
        print(f"       Accuracy: {acc*100:.2f}%, F1: {f1*100:.2f}%")

        if f1 > best_f1:
            best_f1 = f1
            best_name = name
            best_model = model

    # Generate detailed evaluation metrics on best model
    best_y_pred = best_model.predict(X_test_scaled)
    conf_matrix = confusion_matrix(y_test, best_y_pred).tolist()
    clf_report = classification_report(y_test, best_y_pred, target_names=class_names, output_dict=True, zero_division=0)

    # Calculate false positive rate for benign class
    benign_idx = class_names.index('BENIGN') if 'BENIGN' in class_names else 0
    fp = sum(conf_matrix[i][benign_idx] for i in range(len(class_names)) if i != benign_idx)
    tn = conf_matrix[benign_idx][benign_idx]
    fpr = round(float(fp / (fp + tn + 1e-9)) * 100, 3)

    metrics_payload = {
        "best_model_name": best_name,
        "classes": class_names,
        "features": FEATURE_COLUMNS,
        "model_comparison": comparison_results,
        "confusion_matrix": conf_matrix,
        "classification_report": clf_report,
        "false_positive_rate": fpr,
        "test_samples": len(y_test),
        "train_samples": len(y_train)
    }

    # Save artifacts
    model_path = os.path.join(models_dir, "model.joblib")
    scaler_path = os.path.join(models_dir, "scaler.joblib")
    le_path = os.path.join(models_dir, "label_encoder.joblib")
    metrics_path = os.path.join(models_dir, "evaluation_metrics.json")

    joblib.dump(best_model, model_path)
    joblib.dump(scaler, scaler_path)
    joblib.dump(label_encoder, le_path)

    with open(metrics_path, "w") as f:
        json.dump(metrics_payload, f, indent=2)

    print(f"[*] Best model '{best_name}' serialized to {model_path}")
    print(f"[*] Evaluation metrics saved to {metrics_path}")
    return metrics_payload

if __name__ == "__main__":
    train_and_evaluate_models()
