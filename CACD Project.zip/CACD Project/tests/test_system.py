"""
System Verification and Unit Test Suite.
Tests Preprocessing, ML Inference, Rule-Based Engine, SHA-512 Cryptographic Integrity,
SQLite Logging, and Flask API endpoints.
"""
import os
import sys
import unittest
import json
import sqlite3
import pandas as pd

# Add project root to sys.path
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

from src.preprocessor import clean_dataframe, extract_feature_vector
from src.rule_engine import evaluate_security_rules
from src.classifier import classify_security_event
from src.integrity_service import compute_sha512_hash, verify_record_hash
from src.database import init_db, insert_log_record, insert_alert, run_integrity_audit, simulate_tampering
from src.alert_manager import process_and_record_log
from app import app

TEST_DB_PATH = os.path.join(BASE_DIR, "data", "test_security.db")

class SystemTestSuite(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        init_db(TEST_DB_PATH)
        app.config['TESTING'] = True
        cls.client = app.test_client()

    @classmethod
    def tearDownClass(cls):
        if os.path.exists(TEST_DB_PATH):
            os.remove(TEST_DB_PATH)

    def test_01_preprocessing_and_vector(self):
        sample_df = pd.DataFrame([{
            'Destination Port': 80,
            'Flow Duration': 1.5,
            'Tot Fwd Pkts': 10,
            'Tot Bwd Pkts': 8,
            'TotLen Fwd Pkts': 1200,
            'TotLen Bwd Pkts': 800,
            'Flow Byts/s': 1333.3,
            'Flow Pkts/s': 12.0,
            'SYN Flag Cnt': 1,
            'ACK Flag Cnt': 1,
            'RST Flag Cnt': 0,
            'Protocol': 'TCP'
        }])
        cleaned = clean_dataframe(sample_df)
        self.assertIn('dest_port', cleaned.columns)
        self.assertIn('protocol_num', cleaned.columns)
        self.assertEqual(cleaned['protocol_num'].iloc[0], 6)

        record = cleaned.iloc[0].to_dict()
        vector = extract_feature_vector(record)
        self.assertEqual(len(vector), 13)

    def test_02_rule_engine(self):
        # Test Brute Force rule
        bf_record = {'dest_port': 22, 'failed_login_attempts': 5, 'flow_packets_per_sec': 80.0}
        attack, severity, reason = evaluate_security_rules(bf_record)
        self.assertEqual(attack, "Brute Force")
        self.assertEqual(severity, "HIGH")

        # Test DoS SYN flood rule
        dos_record = {'syn_flag_count': 60, 'ack_flag_count': 0, 'flow_packets_per_sec': 6000}
        attack, severity, reason = evaluate_security_rules(dos_record)
        self.assertEqual(attack, "DoS/DDoS")
        self.assertEqual(severity, "CRITICAL")

        # Test Benign
        benign_rec = {'dest_port': 443, 'failed_login_attempts': 0, 'syn_flag_count': 1, 'ack_flag_count': 1}
        attack, severity, reason = evaluate_security_rules(benign_rec)
        self.assertIsNone(attack)

    def test_03_sha512_cryptographic_integrity(self):
        rec = {
            'timestamp': '2026-09-03 12:00:00',
            'source_ip': '192.168.1.100',
            'dest_ip': '10.0.0.1',
            'source_port': 50000,
            'dest_port': 80,
            'protocol': 'TCP',
            'flow_duration': 2.0,
            'total_fwd_packets': 10,
            'total_bwd_packets': 10,
            'total_fwd_bytes': 1000,
            'total_bwd_bytes': 1000,
            'flow_bytes_per_sec': 1000.0,
            'flow_packets_per_sec': 10.0,
            'syn_flag_count': 1,
            'ack_flag_count': 1,
            'rst_flag_count': 0,
            'failed_login_attempts': 0,
            'predicted_label': 'BENIGN'
        }
        hash1 = compute_sha512_hash(rec)
        self.assertEqual(len(hash1), 128) # SHA-512 hex is 128 characters

        # Verification check
        valid, computed = verify_record_hash(rec, hash1)
        self.assertTrue(valid)

        # Unauthorized alteration
        rec_altered = dict(rec)
        rec_altered['predicted_label'] = 'DoS/DDoS'
        valid_altered, computed_altered = verify_record_hash(rec_altered, hash1)
        self.assertFalse(valid_altered)
        self.assertNotEqual(hash1, computed_altered)

    def test_04_tamper_detection_in_database(self):
        rec = {
            'timestamp': '2026-09-03 12:05:00',
            'source_ip': '10.10.10.10',
            'dest_ip': '10.0.0.5',
            'source_port': 44444,
            'dest_port': 22,
            'protocol': 'TCP',
            'predicted_label': 'Brute Force'
        }
        log_id = insert_log_record(rec, db_path=TEST_DB_PATH)
        self.assertGreater(log_id, 0)

        # Run initial audit -> should pass
        audit1 = run_integrity_audit(db_path=TEST_DB_PATH)
        self.assertEqual(audit1['status'], 'PASSED')
        self.assertEqual(audit1['tampered_count'], 0)

        # Simulate tampering
        tampered = simulate_tampering(log_id, db_path=TEST_DB_PATH)
        self.assertTrue(tampered[0])

        # Run audit again -> should detect compromise
        audit2 = run_integrity_audit(db_path=TEST_DB_PATH)
        self.assertEqual(audit2['status'], 'COMPROMISED')
        self.assertEqual(audit2['tampered_count'], 1)
        self.assertIn(log_id, audit2['tampered_ids'])

    def test_05_flask_web_endpoints(self):
        # Test Dashboard
        res = self.client.get('/')
        self.assertEqual(res.status_code, 200)
        self.assertIn(b'Security Operations Center Dashboard', res.data)

        # Test Logs page
        res = self.client.get('/logs')
        self.assertEqual(res.status_code, 200)

        # Test Alerts page
        res = self.client.get('/alerts')
        self.assertEqual(res.status_code, 200)

        # Test Analyze page
        res = self.client.get('/analyze')
        self.assertEqual(res.status_code, 200)

        # Test Integrity page
        res = self.client.get('/integrity')
        self.assertEqual(res.status_code, 200)

        # Test Metrics page
        res = self.client.get('/metrics')
        self.assertEqual(res.status_code, 200)
        self.assertIn(b'Confusion Matrix', res.data)

        # Test API Stats
        res = self.client.get('/api/stats')
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertIn('threat_dist', data)
        self.assertIn('severity_dist', data)

        # Test API single flow analysis
        flow_payload = {
            'source_ip': '192.168.1.188',
            'dest_ip': '10.0.0.10',
            'dest_port': 22,
            'protocol': 'TCP',
            'failed_login_attempts': 8,
            'flow_packets_per_sec': 90.0,
            'syn_flag_count': 5,
            'ack_flag_count': 5
        }
        res = self.client.post('/api/analyze/single', json=flow_payload)
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertTrue(data['success'])
        self.assertEqual(data['classification']['predicted_label'], 'Brute Force')
        self.assertTrue(data['alert_generated'])
        self.assertIn('integrity_hash', data)
        self.assertEqual(len(data['integrity_hash']), 128)

    def test_06_multi_format_parsing(self):
        from src.multi_parser import parse_any_file

        # 1. Test JSON
        json_file = os.path.join(BASE_DIR, "data", "test_sample.json")
        with open(json_file, "w") as f:
            json.dump([
                {"src_ip": "192.168.1.10", "dest_ip": "10.0.0.1", "src_port": 50000, "dest_port": 80, "proto": "TCP"}
            ], f)
        res_json = parse_any_file(json_file, "test_sample.json")
        self.assertEqual(len(res_json), 1)
        self.assertEqual(res_json[0]['dest_port'], 80)
        if os.path.exists(json_file): os.remove(json_file)

        # 2. Test Text / Auth log (SSH Brute Force signature)
        log_file = os.path.join(BASE_DIR, "data", "test_auth.log")
        with open(log_file, "w") as f:
            f.write("Oct 8 08:00:01 server sshd[1234]: Failed password for invalid user root from 203.0.113.50 port 44222 ssh2\n")
            f.write("Oct 8 08:00:03 server sshd[1235]: Failed password for invalid user admin from 203.0.113.50 port 44224 ssh2\n")
            f.write("Oct 8 08:00:05 server sshd[1236]: Failed password for invalid user test from 203.0.113.50 port 44226 ssh2\n")
        res_log = parse_any_file(log_file, "test_auth.log")
        self.assertGreaterEqual(len(res_log), 3)
        self.assertEqual(res_log[-1]['source_ip'], "203.0.113.50")
        self.assertEqual(res_log[-1]['failed_login_attempts'], 3)
        if os.path.exists(log_file): os.remove(log_file)

        # 3. Test XML
        xml_file = os.path.join(BASE_DIR, "data", "test_event.xml")
        with open(xml_file, "w") as f:
            f.write("<Events><Event><EventID>4625</EventID><IpAddress>198.51.100.99</IpAddress></Event></Events>")
        res_xml = parse_any_file(xml_file, "test_event.xml")
        self.assertEqual(len(res_xml), 1)
        self.assertEqual(res_xml[0]['source_ip'], "198.51.100.99")
        if os.path.exists(xml_file): os.remove(xml_file)

    def test_07_firewall_quarantine_and_interception(self):
        from src.database import block_ip, unblock_ip, is_ip_blocked
        test_ip = "198.51.100.222"

        # 1. Block IP
        res = self.client.post('/api/firewall/block', json={'ip_address': test_ip, 'reason': 'Test DDoS', 'severity': 'CRITICAL'})
        self.assertEqual(res.status_code, 200)
        self.assertTrue(res.get_json()['success'])
        self.assertTrue(is_ip_blocked(test_ip))

        # 2. Check classifier drops incoming connection from this IP
        flow_payload = {
            'source_ip': test_ip,
            'dest_ip': '10.0.0.5',
            'dest_port': 80,
            'protocol': 'TCP'
        }
        res_analyze = self.client.post('/api/analyze/single', json=flow_payload)
        self.assertEqual(res_analyze.status_code, 200)
        cls = res_analyze.get_json()['classification']
        self.assertEqual(cls['predicted_label'], 'DROPPED (FIREWALL)')
        self.assertEqual(cls['detection_source'], 'FIREWALL')

        # 3. Unblock IP
        res_unblock = self.client.post('/api/firewall/unblock', json={'ip_address': test_ip})
        self.assertEqual(res_unblock.status_code, 200)
        self.assertFalse(is_ip_blocked(test_ip))

if __name__ == '__main__':
    unittest.main()
