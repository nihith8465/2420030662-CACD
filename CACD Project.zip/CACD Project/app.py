"""
Flask Application for AI-Based Security Log Analysis and Threat Detection.
Integrates Machine Learning threat classification, Rule-based explainability,
SHA-512 cryptographic log integrity audit, and an interactive Cyber SOC dashboard.
"""
import os
import json
import sqlite3
from flask import Flask, render_template, request, jsonify, redirect, url_for, flash
import pandas as pd

from src.database import (
    DB_PATH, get_connection, init_db, insert_log_record, insert_alert,
    get_logs, count_logs, get_alerts, count_alerts, run_integrity_audit, simulate_tampering
)
from src.classifier import classify_security_event
from src.alert_manager import process_and_record_log
from src.integrity_service import compute_sha512_hash, verify_record_hash

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
METRICS_PATH = os.path.join(BASE_DIR, "models", "evaluation_metrics.json")

app = Flask(__name__)
app.secret_key = "security-threat-detection-secret-key"
app.config['UPLOAD_FOLDER'] = os.path.join(BASE_DIR, "data")
app.config['MAX_CONTENT_LENGTH'] = 32 * 1024 * 1024  # 32MB max upload

# Ensure database is initialized on startup
init_db(DB_PATH)

def load_evaluation_metrics():
    if os.path.exists(METRICS_PATH):
        with open(METRICS_PATH, 'r') as f:
            return json.load(f)
    return {}

@app.route('/')
def dashboard():
    conn = get_connection(DB_PATH)
    cursor = conn.cursor()

    # High-level statistics
    cursor.execute("SELECT COUNT(*) FROM security_logs")
    total_logs = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM security_logs WHERE predicted_label = 'BENIGN'")
    benign_count = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM alerts")
    total_alerts = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM alerts WHERE severity = 'CRITICAL'")
    critical_alerts = cursor.fetchone()[0]

    # Latest Audit status
    cursor.execute("SELECT status, passed, total_checked, timestamp FROM integrity_audits ORDER BY id DESC LIMIT 1")
    latest_audit = cursor.fetchone()
    if latest_audit:
        integrity_status = latest_audit['status']
        integrity_detail = f"{latest_audit['passed']}/{latest_audit['total_checked']} records verified"
    else:
        integrity_status = "UNKNOWN"
        integrity_detail = "No audit performed yet"

    # Recent Alerts
    cursor.execute("SELECT * FROM alerts ORDER BY id DESC LIMIT 6")
    recent_alerts = [dict(r) for r in cursor.fetchall()]

    conn.close()

    metrics = load_evaluation_metrics()
    model_name = metrics.get('best_model_name', 'Random Forest')
    model_accuracy = metrics.get('model_comparison', {}).get(model_name, {}).get('accuracy', 99.9)

    return render_template(
        'dashboard.html',
        total_logs=total_logs,
        benign_count=benign_count,
        threat_count=total_logs - benign_count,
        total_alerts=total_alerts,
        critical_alerts=critical_alerts,
        integrity_status=integrity_status,
        integrity_detail=integrity_detail,
        recent_alerts=recent_alerts,
        model_name=model_name,
        model_accuracy=model_accuracy
    )

@app.route('/api/stats')
def api_stats():
    """
    Returns aggregated JSON data for Chart.js rendering.
    """
    conn = get_connection(DB_PATH)
    cursor = conn.cursor()

    # 1. Threat distribution by Attack Type
    cursor.execute("""
        SELECT predicted_label, COUNT(*) as count 
        FROM security_logs 
        GROUP BY predicted_label 
        ORDER BY count DESC
    """)
    threat_dist = {r['predicted_label']: r['count'] for r in cursor.fetchall()}

    # 2. Alerts by Severity
    cursor.execute("""
        SELECT severity, COUNT(*) as count 
        FROM alerts 
        GROUP BY severity
    """)
    severity_dist = {r['severity']: r['count'] for r in cursor.fetchall()}

    # 3. Top 6 Source IPs with Attacks
    cursor.execute("""
        SELECT source_ip, COUNT(*) as attack_count 
        FROM alerts 
        GROUP BY source_ip 
        ORDER BY attack_count DESC 
        LIMIT 6
    """)
    top_ips = [{'ip': r['source_ip'], 'count': r['attack_count']} for r in cursor.fetchall()]

    # 4. Traffic Activity Timeline
    cursor.execute("""
        SELECT strftime('%H:%M', created_at) as time_slot,
               COUNT(*) as total_events,
               SUM(CASE WHEN predicted_label != 'BENIGN' THEN 1 ELSE 0 END) as threat_events
        FROM security_logs
        GROUP BY time_slot
        ORDER BY time_slot ASC
        LIMIT 12
    """)
    timeline_rows = cursor.fetchall()
    if not timeline_rows:
        timeline = {'labels': ['10:00', '10:15', '10:30', '10:45', '11:00', '11:15'], 'events': [25, 40, 30, 28, 35, 20], 'threats': [5, 20, 15, 12, 18, 10]}
    else:
        timeline = {
            'labels': [r['time_slot'] for r in timeline_rows],
            'events': [r['total_events'] for r in timeline_rows],
            'threats': [r['threat_events'] or 0 for r in timeline_rows]
        }

    conn.close()

    return jsonify({
        'threat_dist': threat_dist,
        'severity_dist': severity_dist,
        'top_ips': top_ips,
        'timeline': timeline
    })

@app.route('/logs')
def logs_view():
    page = request.args.get('page', 1, type=int)
    per_page = 20
    offset = (page - 1) * per_page
    label_filter = request.args.get('label', '')
    ip_filter = request.args.get('ip', '').strip()

    conn = get_connection(DB_PATH)
    cursor = conn.cursor()

    query = "SELECT * FROM security_logs WHERE 1=1"
    params = []

    if label_filter:
        query += " AND predicted_label = ?"
        params.append(label_filter)
    if ip_filter:
        query += " AND (source_ip LIKE ? OR dest_ip LIKE ?)"
        params.extend([f"%{ip_filter}%", f"%{ip_filter}%"])

    # Count total matching
    count_query = query.replace("SELECT *", "SELECT COUNT(*)")
    cursor.execute(count_query, params)
    total_matching = cursor.fetchone()[0]

    # Fetch page
    query += " ORDER BY id DESC LIMIT ? OFFSET ?"
    params.extend([per_page, offset])
    cursor.execute(query, params)
    logs = [dict(r) for r in cursor.fetchall()]

    # Get distinct attack labels for filter dropdown
    cursor.execute("SELECT DISTINCT predicted_label FROM security_logs ORDER BY predicted_label")
    available_labels = [r[0] for r in cursor.fetchall()]

    cursor.execute("SELECT ip_address FROM firewall_rules WHERE status = 'BLOCKED'")
    blocked_ips = {r[0] for r in cursor.fetchall()}

    conn.close()

    total_pages = max(1, (total_matching + per_page - 1) // per_page)

    return render_template(
        'logs.html',
        logs=logs,
        page=page,
        total_pages=total_pages,
        total_matching=total_matching,
        current_label=label_filter,
        current_ip=ip_filter,
        available_labels=available_labels,
        blocked_ips=blocked_ips
    )

@app.route('/alerts')
def alerts_view():
    severity_filter = request.args.get('severity', 'ALL')
    page = request.args.get('page', 1, type=int)
    per_page = 20
    offset = (page - 1) * per_page

    conn = get_connection(DB_PATH)
    cursor = conn.cursor()

    query = "SELECT * FROM alerts WHERE 1=1"
    params = []
    if severity_filter and severity_filter != 'ALL':
        query += " AND severity = ?"
        params.append(severity_filter)

    count_query = query.replace("SELECT *", "SELECT COUNT(*)")
    cursor.execute(count_query, params)
    total_matching = cursor.fetchone()[0]

    query += " ORDER BY id DESC LIMIT ? OFFSET ?"
    params.extend([per_page, offset])
    cursor.execute(query, params)
    alerts = [dict(r) for r in cursor.fetchall()]

    cursor.execute("SELECT ip_address FROM firewall_rules WHERE status = 'BLOCKED'")
    blocked_ips = {r[0] for r in cursor.fetchall()}

    conn.close()
    total_pages = max(1, (total_matching + per_page - 1) // per_page)

    return render_template(
        'alerts.html',
        alerts=alerts,
        current_severity=severity_filter,
        page=page,
        total_pages=total_pages,
        total_matching=total_matching,
        blocked_ips=blocked_ips
    )

@app.route('/analyze')
def analyze_view():
    return render_template('analyze.html')

@app.route('/api/analyze/single', methods=['POST'])
def api_analyze_single():
    data = request.json or request.form.to_dict()
    if not data:
        return jsonify({'error': 'No input data provided'}), 400

    import datetime
    now_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    record = {
        'timestamp': data.get('timestamp', now_str),
        'source_ip': data.get('source_ip', '192.168.1.105'),
        'dest_ip': data.get('dest_ip', '10.0.0.1'),
        'source_port': int(data.get('source_port', 49152)),
        'dest_port': int(data.get('dest_port', 80)),
        'protocol': data.get('protocol', 'TCP'),
        'flow_duration': float(data.get('flow_duration', 1.0)),
        'total_fwd_packets': int(data.get('total_fwd_packets', 10)),
        'total_bwd_packets': int(data.get('total_bwd_packets', 10)),
        'total_fwd_bytes': int(data.get('total_fwd_bytes', 1000)),
        'total_bwd_bytes': int(data.get('total_bwd_bytes', 1000)),
        'flow_bytes_per_sec': float(data.get('flow_bytes_per_sec', 2000.0)),
        'flow_packets_per_sec': float(data.get('flow_packets_per_sec', 20.0)),
        'syn_flag_count': int(data.get('syn_flag_count', 1)),
        'ack_flag_count': int(data.get('ack_flag_count', 1)),
        'rst_flag_count': int(data.get('rst_flag_count', 0)),
        'failed_login_attempts': int(data.get('failed_login_attempts', 0))
    }

    result = process_and_record_log(record)
    return jsonify({
        'success': True,
        'classification': result['classification'],
        'log_id': result['log_entry']['id'],
        'integrity_hash': result['log_entry']['integrity_hash'],
        'alert_generated': result['alert'] is not None,
        'alert': result['alert']
    })

@app.route('/api/analyze/upload', methods=['POST'])
def api_analyze_upload():
    if 'file' not in request.files:
        flash('No file uploaded', 'error')
        return redirect(url_for('analyze_view'))

    file = request.files['file']
    if file.filename == '':
        flash('No file selected', 'error')
        return redirect(url_for('analyze_view'))

    temp_path = os.path.join(app.config['UPLOAD_FOLDER'], f"upload_{file.filename}")
    try:
        file.save(temp_path)
        from src.multi_parser import parse_any_file
        parsed_records = parse_any_file(temp_path, file.filename)

        ingested_count = 0
        alerts_count = 0
        limit = min(500, len(parsed_records))

        for i in range(limit):
            row_dict = parsed_records[i]
            res = process_and_record_log(row_dict)
            ingested_count += 1
            if res.get('alert'):
                alerts_count += 1

        flash(f"Successfully processed '{file.filename}' ({ingested_count} events ingested). {alerts_count} threat alerts flagged.", 'success')
    except Exception as e:
        flash(f"Error processing file '{file.filename}': {str(e)}", 'error')
    finally:
        if os.path.exists(temp_path):
            try:
                os.remove(temp_path)
            except Exception:
                pass

    return redirect(url_for('logs_view'))

@app.route('/integrity')
def integrity_view():
    conn = get_connection(DB_PATH)
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM integrity_audits ORDER BY id DESC LIMIT 10")
    audit_history = [dict(r) for r in cursor.fetchall()]

    # Fetch a sample log record for demonstration
    cursor.execute("SELECT * FROM security_logs ORDER BY id DESC LIMIT 1")
    latest_row = cursor.fetchone()
    latest_record = dict(latest_row) if latest_row else None

    conn.close()

    return render_template(
        'integrity.html',
        audit_history=audit_history,
        latest_record=latest_record
    )

@app.route('/api/integrity/verify', methods=['POST'])
def api_integrity_verify():
    result = run_integrity_audit(DB_PATH)
    return jsonify(result)

@app.route('/api/integrity/simulate-tamper', methods=['POST'])
def api_simulate_tamper():
    data = request.json or request.form.to_dict() or {}
    log_id = data.get('log_id')
    field_name = data.get('field_name', 'predicted_label')
    new_value = data.get('new_value', None)

    conn = get_connection(DB_PATH)
    cursor = conn.cursor()
    if not log_id:
        cursor.execute("SELECT id FROM security_logs ORDER BY id DESC LIMIT 1")
        row = cursor.fetchone()
        if not row:
            conn.close()
            return jsonify({'success': False, 'error': 'No logs in database to tamper'}), 400
        log_id = row[0]
    else:
        log_id = int(log_id)
    conn.close()

    success, old_val, applied_val = simulate_tampering(log_id, field_name, new_value, DB_PATH)
    if not success:
        return jsonify({'success': False, 'error': f'Log record #{log_id} not found'}), 404

    return jsonify({
        'success': True,
        'tampered_log_id': log_id,
        'field_modified': field_name,
        'old_value': str(old_val),
        'new_value': str(applied_val),
        'message': f"Log ID #{log_id} was modified: field '{field_name}' changed from '{old_val}' to '{applied_val}' without updating SHA-512 signature. Run audit to detect!"
    })

@app.route('/api/alerts/<int:alert_id>/resolve', methods=['POST'])
def api_resolve_alert(alert_id: int):
    data = request.json or request.form.to_dict() or {}
    analyst_name = data.get('analyst_name', 'Security Analyst').strip()
    resolution_notes = data.get('resolution_notes', 'Resolved after review').strip()

    from src.database import resolve_alert_record
    resolve_alert_record(alert_id, analyst_name, resolution_notes, DB_PATH)
    return jsonify({
        'success': True,
        'alert_id': alert_id,
        'status': 'RESOLVED',
        'resolved_by': analyst_name,
        'notes': resolution_notes
    })

@app.route('/api/integrity/repair', methods=['POST'])
def api_integrity_repair():
    """
    Recalculates cryptographic SHA-512 hashes and blockchain linkage for all records to restore verified state.
    """
    conn = get_connection(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM security_logs ORDER BY id ASC")
    rows = cursor.fetchall()
    repaired_count = 0
    prev_hash = ""

    for r in rows:
        rec = dict(r)
        rec['previous_hash'] = prev_hash
        new_hash = compute_sha512_hash(rec, prev_hash)
        if new_hash.lower() != (rec.get('integrity_hash') or "").lower() or rec.get('previous_hash', '') != prev_hash:
            cursor.execute("UPDATE security_logs SET previous_hash = ?, integrity_hash = ? WHERE id = ?", (prev_hash, new_hash, rec['id']))
            repaired_count += 1
        prev_hash = new_hash

    conn.commit()
    conn.close()
    
    # Run audit to register clean state
    audit_res = run_integrity_audit(DB_PATH)
    return jsonify({'success': True, 'repaired_count': repaired_count, 'audit': audit_res})

@app.route('/metrics')
def metrics_view():
    metrics = load_evaluation_metrics()
    return render_template('metrics.html', metrics=metrics)

@app.route('/api/export/alerts')
def api_export_alerts():
    """
    Exports all recorded alerts as a downloadable CSV report for forensics.
    """
    import io
    import csv
    from flask import Response

    conn = get_connection(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT id, timestamp, source_ip, dest_ip, attack_type, severity, confidence, rule_triggered, description, status FROM alerts ORDER BY id DESC")
    rows = cursor.fetchall()
    conn.close()

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(['Alert_ID', 'Timestamp', 'Source_IP', 'Target_IP', 'Attack_Type', 'Severity', 'Confidence', 'Rule_Triggered', 'Description', 'Status'])
    for r in rows:
        writer.writerow(list(r))

    output.seek(0)
    return Response(
        output.getvalue(),
        mimetype="text/csv",
        headers={"Content-Disposition": "attachment;filename=soc_incident_alerts_report.csv"}
    )

@app.route('/firewall')
def firewall_view():
    from src.database import get_blocked_ips
    rules = get_blocked_ips(DB_PATH)
    return render_template('firewall.html', rules=rules)

@app.route('/api/firewall/block', methods=['POST'])
def api_firewall_block():
    data = request.json or request.form.to_dict()
    ip = data.get('ip_address', '').strip()
    reason = data.get('reason', 'AI Threat Quarantine')
    severity = data.get('severity', 'HIGH')

    if not ip:
        return jsonify({'success': False, 'error': 'No IP address provided'}), 400

    from src.database import block_ip
    block_ip(ip, reason, severity, DB_PATH)
    return jsonify({'success': True, 'ip_address': ip, 'status': 'BLOCKED'})

@app.route('/api/firewall/unblock', methods=['POST'])
def api_firewall_unblock():
    data = request.json or request.form.to_dict()
    ip = data.get('ip_address', '').strip()
    from src.database import unblock_ip
    unblock_ip(ip, DB_PATH)
    return jsonify({'success': True, 'ip_address': ip, 'status': 'UNBLOCKED'})

@app.route('/api/stream/next')
def api_stream_next():
    """
    Generates a network flow event based on user-selected parameters (or random if not specified),
    runs it through hybrid threat detection, and returns real-time metrics for dynamic SOC streaming.
    """
    import random
    import datetime

    user_attack = request.args.get('attack_type', '').strip()
    user_target = request.args.get('target_ip', '10.0.0.5').strip()
    user_source = request.args.get('source_ip', '').strip()

    valid_types = ['BENIGN', 'DoS/DDoS', 'PortScan', 'Brute Force', 'Web Attack', 'Botnet']
    if user_attack in valid_types:
        chosen = user_attack
    else:
        attack_types = ['BENIGN', 'BENIGN', 'BENIGN', 'DoS/DDoS', 'PortScan', 'Brute Force', 'Web Attack', 'Botnet']
        chosen = random.choice(attack_types)

    now_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    target_ip = user_target if user_target else '10.0.0.5'

    if chosen == 'BENIGN':
        src = user_source if user_source else f"192.168.1.{random.randint(10, 220)}"
        rec = {
            'timestamp': now_str, 'source_ip': src, 'dest_ip': target_ip,
            'dest_port': random.choice([80, 443, 8080]), 'protocol': 'TCP', 'flow_duration': random.uniform(1.0, 10.0),
            'total_fwd_packets': random.randint(5, 30), 'total_bwd_packets': random.randint(5, 30),
            'flow_packets_per_sec': random.uniform(5.0, 25.0), 'flow_bytes_per_sec': random.uniform(500.0, 3000.0),
            'syn_flag_count': 1, 'ack_flag_count': 1, 'rst_flag_count': 0, 'failed_login_attempts': 0
        }
    elif chosen == 'DoS/DDoS':
        src = user_source if user_source else f"172.16.0.{random.randint(2, 250)}"
        rec = {
            'timestamp': now_str, 'source_ip': src, 'dest_ip': target_ip,
            'dest_port': 80, 'protocol': 'TCP', 'flow_duration': 0.5,
            'total_fwd_packets': random.randint(1000, 4000), 'total_bwd_packets': 2,
            'flow_packets_per_sec': 5500.0, 'flow_bytes_per_sec': 1200000.0,
            'syn_flag_count': random.randint(80, 200), 'ack_flag_count': 0, 'rst_flag_count': 1, 'failed_login_attempts': 0
        }
    elif chosen == 'Brute Force':
        src = user_source if user_source else f"203.0.113.{random.randint(10, 90)}"
        rec = {
            'timestamp': now_str, 'source_ip': src, 'dest_ip': target_ip,
            'dest_port': 22, 'protocol': 'TCP', 'flow_duration': 2.0,
            'total_fwd_packets': 45, 'total_bwd_packets': 35,
            'flow_packets_per_sec': 65.0, 'flow_bytes_per_sec': 5000.0,
            'syn_flag_count': 3, 'ack_flag_count': 3, 'rst_flag_count': 1, 'failed_login_attempts': random.randint(4, 15)
        }
    elif chosen == 'PortScan':
        src = user_source if user_source else f"198.51.100.{random.randint(10, 50)}"
        rec = {
            'timestamp': now_str, 'source_ip': src, 'dest_ip': target_ip,
            'dest_port': random.randint(1000, 65000), 'protocol': 'TCP', 'flow_duration': 0.05,
            'total_fwd_packets': 4, 'total_bwd_packets': 0,
            'flow_packets_per_sec': 80.0, 'flow_bytes_per_sec': 300.0,
            'syn_flag_count': 8, 'ack_flag_count': 0, 'rst_flag_count': 2, 'failed_login_attempts': 0
        }
    elif chosen == 'Web Attack':
        src = user_source if user_source else f"198.51.100.{random.randint(100, 200)}"
        rec = {
            'timestamp': now_str, 'source_ip': src, 'dest_ip': target_ip,
            'dest_port': 8080, 'protocol': 'TCP', 'flow_duration': 1.2,
            'total_fwd_packets': 25, 'total_bwd_packets': 18,
            'flow_packets_per_sec': 30.0, 'flow_bytes_per_sec': 25000.0,
            'syn_flag_count': 20, 'ack_flag_count': 4, 'rst_flag_count': 16, 'failed_login_attempts': 0
        }
    else:  # Botnet
        src = user_source if user_source else f"192.168.1.{random.randint(15, 30)}"
        rec = {
            'timestamp': now_str, 'source_ip': src, 'dest_ip': '185.220.101.44',
            'dest_port': 6667, 'protocol': 'TCP', 'flow_duration': 60.0,
            'total_fwd_packets': 50, 'total_bwd_packets': 50,
            'flow_packets_per_sec': 1.8, 'flow_bytes_per_sec': 180.0,
            'syn_flag_count': 1, 'ack_flag_count': 1, 'rst_flag_count': 0, 'failed_login_attempts': 0
        }

    res = process_and_record_log(rec)
    return jsonify({
        'success': True,
        'event': res['log_entry'],
        'classification': res['classification'],
        'alert': res['alert']
    })

@app.route('/report')
def executive_report():
    """
    Renders an executive, printable Security Operations & Compliance Audit Report.
    """
    import datetime
    conn = get_connection(DB_PATH)
    cursor = conn.cursor()

    cursor.execute("SELECT COUNT(*) FROM security_logs")
    total_logs = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM security_logs WHERE predicted_label = 'BENIGN'")
    benign_count = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM alerts")
    total_alerts = cursor.fetchone()[0]

    cursor.execute("SELECT predicted_label, COUNT(*) as c FROM security_logs GROUP BY predicted_label ORDER BY c DESC")
    attack_breakdown = [dict(r) for r in cursor.fetchall()]

    cursor.execute("SELECT source_ip, COUNT(*) as c FROM alerts GROUP BY source_ip ORDER BY c DESC LIMIT 5")
    top_threat_actors = [dict(r) for r in cursor.fetchall()]

    cursor.execute("SELECT * FROM integrity_audits ORDER BY id DESC LIMIT 1")
    latest_audit = cursor.fetchone()

    cursor.execute("SELECT * FROM firewall_rules ORDER BY id DESC")
    blocked_ips = [dict(r) for r in cursor.fetchall()]

    conn.close()

    return render_template(
        'report.html',
        generated_at=datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        total_logs=total_logs,
        benign_count=benign_count,
        threat_count=total_logs - benign_count,
        total_alerts=total_alerts,
        attack_breakdown=attack_breakdown,
        top_threat_actors=top_threat_actors,
        latest_audit=dict(latest_audit) if latest_audit else None,
        blocked_ips=blocked_ips
    )

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
